export interface BusinessPlanInputs {
  idea: string;
  countryCity: string;
  budget: string;
  currency: string;
  skills: string;
  targetCustomers: string;
  businessType: string;
}

export interface BusinessPlan {
  id: string;
  createdAt: string;
  updatedAt?: string;
  inputs: BusinessPlanInputs;
  businessName: string;
  tagline: string;
  executiveSummary: string;
  missionStatement: string;
  uniqueValueProposition: string;
  
  targetMarket: {
    overview: string;
    primaryAudience: string;
    idealCustomerPersona: {
      name: string;
      demographics: string;
      painPoints: string[];
      buyingMotivation: string;
    };
    marketOpportunity?: string;
  };

  customerProblemAndSolution: {
    coreProblem: string;
    currentAlternatives: string;
    ourSolution: string;
    unfairAdvantage?: string;
  };

  productsAndServices: {
    overview: string;
    offerings: Array<{
      name: string;
      description: string;
      priceEstimate: string;
      features?: string[];
    }>;
  };

  revenueModel: {
    modelType: string;
    pricingTiersDescription: string;
    expectedGrossMargin: string;
    customerLifetimeValueStrategy?: string;
    pathwayToFirst10k?: string;
  };

  startupCosts: {
    totalEstimatedBudget: number;
    currency: string;
    monthlyEstimatedRunway?: string;
    itemizedBreakdown: Array<{
      category: string;
      description: string;
      cost: number;
      isEssential: boolean;
    }>;
    moneySavingTips?: string[];
  };

  marketingStrategy: {
    preLaunchStrategy?: string;
    topChannels: Array<{
      channel: string;
      tactic: string;
      costLevel?: string;
    }>;
    conversionFunnel?: string;
    first100CustomersTactic: string;
  };

  risksAndMitigations: Array<{
    risk: string;
    category?: string;
    severity?: string;
    solution: string;
  }>;

  launchPlan30Day: {
    summary: string;
    weeks: Array<{
      weekNumber: number;
      theme: string;
      goals?: string;
      tasks: Array<{
        dayRange: string;
        title: string;
        description: string;
        deliverable?: string;
        completed?: boolean;
      }>;
    }>;
  };
}

export interface BusinessIdea {
  name: string;
  tagline: string;
  businessType: string;
  summary: string;
  targetAudience: string;
  estimatedStartupCost: string;
  monetization: string;
  difficultyLevel?: string;
  timeToFirstDollar?: string;
  whyItWorks?: string;
}

export interface BusinessNameOption {
  name: string;
  tagline: string;
  styleCategory: string;
  domainSuggestion: string;
  vibe: string;
  rationale: string;
}

export interface MarketingKit {
  elevatorPitch: string;
  headlineUVP: string;
  emailSequence: Array<{
    day: string;
    purpose?: string;
    subjectLine: string;
    bodyContent: string;
  }>;
  socialPosts: Array<{
    platform: string;
    hook: string;
    caption: string;
    callToAction?: string;
  }>;
  growthHacks: Array<{
    title: string;
    steps: string;
    expectedCost?: string;
  }>;
  seoPillars: Array<{
    pillar: string;
    primaryKeywords: string[];
    articleIdea?: string;
  }>;
}

export interface LaunchDayTask {
  dayNumber: number;
  title: string;
  category: string;
  description: string;
  checklistItems: string[];
  estimatedHours?: number;
  isMilestone?: boolean;
  completed?: boolean;
}

export interface LaunchPlanDetail {
  title: string;
  objective: string;
  totalTasksCount?: number;
  milestones?: string[];
  days: LaunchDayTask[];
}

export interface FeedbackItem {
  id: string;
  planTitle: string;
  rating: number; // 1 to 5
  category: string;
  message: string;
  improvements: string;
  userEmail?: string;
  metadata?: Record<string, any>;
  createdAt: string;
  status: 'pending_review' | 'reviewed';
}

export type SubscriptionTierType = 'free' | 'starter' | 'pro' | 'unlimited';

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  country?: string;
  city?: string;
  defaultCurrency: string;
  businessFocus?: string;
  subscriptionTier: SubscriptionTierType;
  subscriptionStatus: 'active' | 'trialing' | 'cancelled';
  creditsRemaining: number;
  createdAt: string;
  updatedAt: string;
}

export interface SubscriptionPayment {
  id: string;
  userId: string;
  planId: SubscriptionTierType;
  planName: string;
  amount: number;
  currency: string;
  paymentMethod: string;
  billingInterval: 'monthly' | 'yearly' | 'one-time';
  status: 'succeeded' | 'processing' | 'refunded';
  transactionId: string;
  createdAt: string;
}

export interface PricingPlan {
  id: SubscriptionTierType;
  name: string;
  priceMonthly: number;
  priceYearly: number;
  tagline: string;
  description: string;
  features: string[];
  popular?: boolean;
  buttonText: string;
}

