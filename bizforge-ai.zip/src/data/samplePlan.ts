import { BusinessPlan } from '../types';

export const SAMPLE_PLAN: BusinessPlan = {
  id: 'plan_sample_ecospark',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  inputs: {
    idea: 'EcoSpark: On-demand eco-friendly commercial & office deep cleaning using plant-based non-toxic formulations and certified green sanitization.',
    countryCity: 'Austin, TX, USA',
    budget: '6000',
    currency: 'USD',
    skills: 'Operations management, B2B sales outreach, local networking, customer service',
    targetCustomers: 'Tech startups, co-working spaces, boutique medical clinics, and eco-conscious creative studios with 10-100 employees',
    businessType: 'Local Commercial Service & B2B Subscription',
  },
  businessName: 'EcoSpark Green Facilities',
  tagline: 'Spotless workspaces. Zero toxins. Certified sustainable.',
  executiveSummary: `EcoSpark Green Facilities is a premium B2B commercial cleaning and wellness-standard facility service company founded in Austin, Texas. While conventional commercial janitorial services rely on harsh petrochemical bleaches, ammonias, and volatile organic compounds (VOCs) that irritate staff and diminish indoor air quality, EcoSpark delivers hospital-grade sanitization using 100% plant-based, cruelty-free, and biodegradable cleaning chemistry.

Targeting Austin's fast-growing tech hubs, design studios, co-working campuses, and holistic clinics, EcoSpark operates on a recurring contract model (bi-weekly and monthly subscriptions). With a modest starting capital of $6,000, the company leverages lean operational logistics, commercial-grade HEPA equipment, and certified green technicians to achieve break-even within 60 days and projected $18,000 monthly recurring revenue (MRR) by Month 12.`,
  missionStatement: 'To elevate workplace health and environmental stewardship by delivering impeccably clean, toxin-free commercial spaces with transparent, dependable service.',
  uniqueValueProposition: 'Austin’s only certified Green-Seal standard commercial cleaning service offering 24/7 client portal scheduling, zero-VOC indoor air guarantees, and transparent flat-rate subscription billing.',
  
  targetMarket: {
    overview: 'The US commercial cleaning services industry exceeds $90 billion annually, with eco-friendly and wellness-focused sanitization representing the fastest-growing niche (+14% CAGR). Austin has over 42,000 small-to-midsize commercial offices, with a dense concentration of environmentally conscious startups and wellness clinics.',
    primaryAudience: 'Office Managers, Facility Directors, and Founders of companies with 15 to 150 employees who prioritize team health, sustainability accreditation, and immaculate work environments.',
    idealCustomerPersona: {
      name: 'Sarah Lindqvist (Director of People & Workplace at a 45-person SaaS Company)',
      demographics: '32-45 years old, based in downtown Austin, oversees office perks, health, and vendor operations with a $3,500/month facility maintenance budget.',
      painPoints: [
        'Chemical odors after evening cleaning triggering staff complaints and headaches',
        'Unreliable independent cleaners missing scheduled shifts and sloppy trash segregation',
        'Lack of transparent invoicing and painful manual communication for special requests',
      ],
      buyingMotivation: 'Wants an effortless, set-and-forget vendor who provides documented sustainability badges she can highlight to company employees and ESG reports.',
    },
    marketOpportunity: 'Recent shifts toward hybrid work have made in-office health and clean indoor air a top retention priority, creating urgent demand for modern eco-certified cleaning partners.',
  },

  customerProblemAndSolution: {
    coreProblem: 'Traditional janitorial companies rely on harsh industrial chemical solvents that degrade indoor air quality, trigger allergies, and leave pungent odors, while providing inconsistent service with high employee turnover.',
    currentAlternatives: 'Legacy franchise janitorial firms (slow, rigid contracts, toxic products) or informal gig cleaners (uninsured, inconsistent quality, no commercial certifications).',
    ourSolution: 'EcoSpark provides fully insured, certified green cleaning technicians equipped with HEPA-filtration vacuums, microfiber color-coded systems, proprietary biodegradable solutions, and a mobile client app for automated checklist inspections.',
    unfairAdvantage: 'Proprietary Austin Green Business Partnership certification, automated digital quality logs sent to office managers after every shift, and 98% cleaner retention through living wage compensation.',
  },

  productsAndServices: {
    overview: 'Tailored commercial packages billed on monthly auto-renewal contracts with clear scope and zero hidden supply surcharges.',
    offerings: [
      {
        name: 'Core Green Office Recurring Tier',
        description: 'Bi-weekly or weekly comprehensive night clean: dusting, HEPA vacuuming, trash/recycling, kitchen deep-sanitization, and organic bathroom descaling.',
        priceEstimate: '$650 – $1,400 / month based on square footage',
        features: [
          'EPA Safer Choice & Green Seal certified cleaning supplies',
          'Color-coded microfiber cross-contamination prevention',
          'Restroom touchpoint hospital-grade steam sanitization',
          'Digital post-service photo inspection summary',
        ],
      },
      {
        name: 'Executive Studio & Co-Working Intensive',
        description: '3x weekly or daily high-touch maintenance designed for high foot-traffic collaborative hubs and creative spaces.',
        priceEstimate: '$1,800 – $3,200 / month',
        features: [
          'High-touch surface disinfection (meeting rooms, keyboards, pods)',
          'Glass and architectural partition streak-free detailing',
          'Composting & Zero-Waste bin management',
          'Dedicated account manager with 1-hour response SLA',
        ],
      },
      {
        name: 'Quarterly Deep Steam & Carpet Detox Add-on',
        description: 'Quarterly carpet hot-water extraction, upholstery allergen treatment, and interior architectural glass scrub.',
        priceEstimate: '$450 – $900 per quarterly session',
        features: [
          'Zero-residue citrus bio-solvent carpet rinse',
          'Air quality VOC reading certificate provided to client',
        ],
      },
    ],
  },

  revenueModel: {
    modelType: 'Predictable Monthly Recurring B2B Contract (Retainer) + High-Margin Specialty Add-ons',
    pricingTiersDescription: 'Priced between $0.14 – $0.22 per square foot per cleaning session. Typical client contract values range from $750/mo to $2,400/mo, locked on 6-month or 12-month service agreements with net-15 payment terms.',
    expectedGrossMargin: '68% – 74% gross margin on recurring labor & supplies',
    customerLifetimeValueStrategy: 'B2B office contracts have an average retention of 22+ months. High lifetime value ($18,000+) supported by quarterly floor and carpet care upsells.',
    pathwayToFirst10k: 'Secure 8-10 mid-size office recurring accounts averaging $1,100/mo each via direct LinkedIn Outreach to Austin Office Managers and local Chamber of Commerce networking.',
  },

  startupCosts: {
    totalEstimatedBudget: 5850,
    currency: 'USD',
    monthlyEstimatedRunway: '$850 / month fixed overhead before client revenue',
    itemizedBreakdown: [
      { category: 'Legal & Business Setup', description: 'LLC registration in Texas, EIN, local permits, commercial DBA', cost: 450, isEssential: true },
      { category: 'Insurance & Bonding', description: '$2M General liability insurance + janitorial surety bonding down payment', cost: 650, isEssential: true },
      { category: 'Commercial Equipment', description: '2x Commercial ProTeam Backpack HEPA vacuums, microfiber sets, spray systems', cost: 1350, isEssential: true },
      { category: 'Eco Supplies & Inventory', description: 'Bulk concentrates (Green Seal plant-based multi-surface, glass, enzyme cleaners)', cost: 500, isEssential: true },
      { category: 'Branding & Uniforms', description: 'Embroidered polo shirts, safety ID badges, business cards, vehicle magnets', cost: 400, isEssential: true },
      { category: 'Digital & Software', description: 'Domain, Webflow landing page, Google Workspace, Swept/Jobber trial setup', cost: 500, isEssential: true },
      { category: 'Local Outreach & Marketing', description: 'Targeted LinkedIn Sales Navigator, printed presentation folders, local Austin B2B blitz', cost: 800, isEssential: false },
      { category: 'Reserve Working Capital', description: 'Cash buffer for emergency replacement parts and initial payroll float', cost: 1200, isEssential: true },
    ],
    moneySavingTips: [
      'Lease or purchase refurbished commercial backpack vacuums to save up to 40% on initial hardware.',
      'Purchase eco-friendly cleaning formulas in super-concentrate 5-gallon drums and dilute in-house rather than buying ready-to-use bottles.',
      'Operate without a physical commercial office initially; store supplies in secure storage or work vehicles.',
    ],
  },

  marketingStrategy: {
    preLaunchStrategy: 'Create a "Austin Healthy Office Guide" PDF highlighting VOC hazards in conventional cleaning; distribute directly to 150 local office managers alongside a complimentary eco-friendly sample desk sanitization kit.',
    topChannels: [
      { channel: 'Direct B2B Outreach (LinkedIn & Cold Email)', tactic: 'Target Austin-based "Office Manager", "Operations Lead", and "Head of People" on LinkedIn offering a free 1-room trial clean.', costLevel: 'Low' },
      { channel: 'Local SEO & Google Business Profile', tactic: 'Optimize for "commercial cleaning Austin", "green office janitorial Austin TX", and capture reviews with photo proof.', costLevel: 'Free / Low' },
      { channel: 'Commercial Real Estate Broker Partnerships', tactic: 'Partner with commercial tenant brokers and property management firms to become their recommended move-in janitorial partner.', costLevel: 'Medium (Commission/Referral)' },
    ],
    conversionFunnel: 'Cold Outreach / Local Search -> Free 15-Minute On-Site Walkthrough & Air Quality Assessment -> Custom Proposal with 3 Tier Options -> Signed Contract with 1st Week Satisfaction Guarantee.',
    first100CustomersTactic: 'Execute a referral incentive giving existing clients 20% off one month for every commercial neighbor they introduce in their office park or complex.',
  },

  risksAndMitigations: [
    {
      risk: 'High Cleaner Labor Turnover',
      category: 'Operational',
      severity: 'Medium',
      solution: 'Pay 15% above local janitorial wage averages ($21-24/hr), implement predictable evening scheduling, and provide clear path to Team Lead bonuses.',
    },
    {
      risk: 'Client Property Damage or Theft Accusation',
      category: 'Legal / Trust',
      severity: 'High',
      solution: 'Mandatory criminal background checks for all staff, $2,000,000 comprehensive liability policy, and mandatory key/fob digital audit logs.',
    },
    {
      risk: 'Slow Cashflow due to Net-30 Invoicing',
      category: 'Financial',
      severity: 'Medium',
      solution: 'Require credit card on file with automated Stripe billing on the 1st of every month, with 3% discount for ACH auto-debit.',
    },
    {
      risk: 'Skepticism of Green Cleaning Efficacy',
      category: 'Market',
      severity: 'Low',
      solution: 'Provide third-party lab safety datasheets and perform live ATP swab testing during client sales walkthroughs to prove medical-grade sanitization.',
    },
  ],

  launchPlan30Day: {
    summary: 'A disciplined 4-week execution roadmap moving from state registration and supply procurement to closing the first 3 recurring commercial contracts within 30 days.',
    weeks: [
      {
        weekNumber: 1,
        theme: 'Legal Setup, Equipment Procurement & Insurance',
        goals: 'Establish legal entity, acquire commercial insurance, and test cleaning equipment.',
        tasks: [
          { dayRange: 'Day 1-2', title: 'Entity Registration & Banking', description: 'Register Texas LLC, obtain EIN from IRS, open dedicated business checking and Stripe merchant account.', deliverable: 'Active business bank account & certificate of formation' },
          { dayRange: 'Day 3-4', title: 'Janitorial Insurance & Bond', description: 'Secure $2M commercial general liability insurance and janitorial bonding with certificates of insurance (COI) ready to send to prospective property managers.', deliverable: 'COI PDF ready for clients' },
          { dayRange: 'Day 5-7', title: 'Equipment & Eco-Formulations Purchase', description: 'Order ProTeam HEPA backpack vacuums, color-coded microfiber towels, and Green Seal approved concentrates. Test protocols in friendly local office.', deliverable: 'Turnkey mobile equipment kit' },
        ],
      },
      {
        weekNumber: 2,
        theme: 'Brand Assets, Landing Page & Sales Collateral',
        goals: 'Establish professional web presence, proposal templates, and client walk-through checklists.',
        tasks: [
          { dayRange: 'Day 8-10', title: 'High-Converting Web Presence', description: 'Deploy responsive landing page with Austin location focus, client quote calculator, and booking integration for free site walkthroughs.', deliverable: 'Live website & Google Business Profile submission' },
          { dayRange: 'Day 11-12', title: 'Standard Operating Procedures & Checklists', description: 'Draft standardized 50-point cleaning checklist, safety data sheets binder, and employee handbook.', deliverable: 'Digital inspection checklist template' },
          { dayRange: 'Day 13-14', title: 'Sales Proposal & Contract Templates', description: 'Create clean, modern proposal deck with digital signing via DocuSign or PandaDoc including terms of service and SLA.', deliverable: '1-click proposal template' },
        ],
      },
      {
        weekNumber: 3,
        theme: 'Targeted B2B Outreach & Direct Prospecting',
        goals: 'Initiate contact with 150 local office managers and schedule 8 on-site walkthroughs.',
        tasks: [
          { dayRange: 'Day 15-17', title: 'Prospect List Building', description: 'Compile list of 150 target tech offices, creative agencies, and clinics in Austin using LinkedIn and local business directories.', deliverable: 'Verified prospect spreadsheet with direct phone/email' },
          { dayRange: 'Day 18-19', title: 'Direct Outreach Campaign Kickoff', description: 'Send personalized emails and LinkedIn InMails offering a complimentary air quality assessment and 1-room trial clean.', deliverable: '150 personalized messages sent' },
          { dayRange: 'Day 20-21', title: 'In-Person Commercial Park Drop-ins', description: 'Visit 3 local business parks with branded eco-friendly sample kits and introduction brochures for receptionist handoffs.', deliverable: '25 in-person drop-ins completed' },
        ],
      },
      {
        weekNumber: 4,
        theme: 'Walkthroughs, Proposal Closing & Onboarding First Clients',
        goals: 'Conduct on-site walkthroughs, close first 2-3 recurring contracts, and execute maiden cleans.',
        tasks: [
          { dayRange: 'Day 22-25', title: 'On-site Office Walkthroughs', description: 'Measure square footage, document high-traffic areas, calculate exact pricing, and present proposal within 4 hours of visit.', deliverable: 'Minimum 5 on-site walkthroughs conducted' },
          { dayRange: 'Day 26-27', title: 'Contract Negotiation & Signing', description: 'Follow up on proposals, offer a "1st Month Satisfaction Guarantee", and collect signed agreements with credit card deposits.', deliverable: 'First 2 paying contracts signed ($1,500+ MRR)' },
          { dayRange: 'Day 28-30', title: 'Maiden Cleaning Shifts & Review Capture', description: 'Execute inaugural cleaning shifts with extreme attention to detail; send post-clean photo report to office manager and request 5-star Google review.', deliverable: 'Successful launch with initial raving client testimonials' },
        ],
      },
    ],
  },
};
