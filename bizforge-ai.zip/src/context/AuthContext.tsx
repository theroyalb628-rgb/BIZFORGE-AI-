import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithPopup,
  signOut as fbSignOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile as fbUpdateProfile,
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, collection, addDoc, onSnapshot } from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType, testConnection } from '../firebase';
import { UserProfile, SubscriptionPayment, SubscriptionTierType } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string, name: string) => Promise<void>;
  logout: () => Promise<void>;
  updateUserProfile: (updates: Partial<UserProfile>) => Promise<void>;
  recordPaymentAndUpgrade: (paymentData: Omit<SubscriptionPayment, 'id' | 'userId' | 'createdAt'>) => Promise<SubscriptionPayment>;
  userPayments: SubscriptionPayment[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [userPayments, setUserPayments] = useState<SubscriptionPayment[]>([]);

  useEffect(() => {
    testConnection();

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        await syncUserProfile(currentUser);
        // Listen to payment history in Firestore
        const paymentsRef = collection(db, 'users', currentUser.uid, 'payments');
        const unsubPayments = onSnapshot(
          paymentsRef,
          (snapshot) => {
            const list: SubscriptionPayment[] = [];
            snapshot.forEach((d) => {
              list.push({ id: d.id, ...d.data() } as SubscriptionPayment);
            });
            list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            setUserPayments(list);
          },
          (err) => {
            handleFirestoreError(err, OperationType.GET, `users/${currentUser.uid}/payments`);
          }
        );
        return () => unsubPayments();
      } else {
        setProfile(null);
        setUserPayments([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const syncUserProfile = async (currentUser: User) => {
    try {
      const userRef = doc(db, 'users', currentUser.uid);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        setProfile({ uid: currentUser.uid, ...userSnap.data() } as UserProfile);
      } else {
        // Create initial default profile in Firestore
        const initialProfile: UserProfile = {
          uid: currentUser.uid,
          displayName: currentUser.displayName || currentUser.email?.split('@')[0] || 'Founder',
          email: currentUser.email || '',
          photoURL: currentUser.photoURL || '',
          country: 'United States',
          city: 'Austin',
          defaultCurrency: 'USD',
          businessFocus: 'Digital & Local Services',
          subscriptionTier: 'free',
          subscriptionStatus: 'active',
          creditsRemaining: 3,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await setDoc(userRef, initialProfile);
        setProfile(initialProfile);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `users/${currentUser.uid}`);
      // Fallback in-memory profile if Firestore permissions are syncing
      setProfile({
        uid: currentUser.uid,
        displayName: currentUser.displayName || 'Founder',
        email: currentUser.email || '',
        photoURL: currentUser.photoURL || '',
        defaultCurrency: 'USD',
        subscriptionTier: 'free',
        subscriptionStatus: 'active',
        creditsRemaining: 3,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    } finally {
      setLoading(false);
    }
  };

  const signInWithGoogle = async () => {
    const res = await signInWithPopup(auth, googleProvider);
    if (res.user) {
      await syncUserProfile(res.user);
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    const res = await signInWithEmailAndPassword(auth, email, pass);
    if (res.user) {
      await syncUserProfile(res.user);
    }
  };

  const signUpWithEmail = async (email: string, pass: string, name: string) => {
    const res = await createUserWithEmailAndPassword(auth, email, pass);
    if (res.user) {
      await fbUpdateProfile(res.user, { displayName: name });
      await syncUserProfile(res.user);
    }
  };

  const logout = async () => {
    await fbSignOut(auth);
    setUser(null);
    setProfile(null);
    setUserPayments([]);
  };

  const updateUserProfile = async (updates: Partial<UserProfile>) => {
    if (!user || !profile) return;
    const updatedData = {
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, updatedData);
      setProfile((prev) => (prev ? { ...prev, ...updatedData } : null));
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
      // Optimistic update
      setProfile((prev) => (prev ? { ...prev, ...updatedData } : null));
    }
  };

  const recordPaymentAndUpgrade = async (
    paymentData: Omit<SubscriptionPayment, 'id' | 'userId' | 'createdAt'>
  ): Promise<SubscriptionPayment> => {
    if (!user) throw new Error('Must be logged in to process payment');

    const paymentRecord: SubscriptionPayment = {
      id: 'pay_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      userId: user.uid,
      createdAt: new Date().toISOString(),
      ...paymentData,
    };

    try {
      const paymentsRef = collection(db, 'users', user.uid, 'payments');
      await addDoc(paymentsRef, paymentRecord);

      // Update user subscription in profile
      await updateUserProfile({
        subscriptionTier: paymentData.planId,
        subscriptionStatus: 'active',
        creditsRemaining: paymentData.planId === 'unlimited' ? 9999 : 50,
      });

      setUserPayments((prev) => [paymentRecord, ...prev]);
      return paymentRecord;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `users/${user.uid}/payments`);
      // Update locally
      await updateUserProfile({
        subscriptionTier: paymentData.planId,
        subscriptionStatus: 'active',
        creditsRemaining: paymentData.planId === 'unlimited' ? 9999 : 50,
      });
      setUserPayments((prev) => [paymentRecord, ...prev]);
      return paymentRecord;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        logout,
        updateUserProfile,
        recordPaymentAndUpgrade,
        userPayments,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
