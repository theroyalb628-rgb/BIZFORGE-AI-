import React, { useState } from 'react';
import {
  Lightbulb,
  Sparkles,
  ArrowRight,
  DollarSign,
  Clock,
  Layers,
  MapPin,
  CheckCircle,
  AlertCircle,
  Zap,
} from 'lucide-react';
import { BusinessIdea, BusinessPlanInputs } from '../types';

interface IdeaGeneratorProps {
  onUseIdeaInPlan: (inputs: Partial<BusinessPlanInputs>) => void;
}

const PRESET_INTERESTS = [
  'Artificial Intelligence & Productivity',
  'Health, Wellness & Fitness',
  'Sustainable & Green Living',
  'E-commerce & Physical Products',
  'B2B Services & Agency',
  'Food, Beverage & Hospitality',
];

export const IdeaGenerator: React.FC<IdeaGeneratorProps> = ({ onUseIdeaInPlan }) => {
  const [interests, setInterests] = useState('Technology, automation, and green living');
  const [budget, setBudget] = useState('4000');
  const [currency, setCurrency] = useState('USD');
  const [location, setLocation] = useState('Austin, TX, USA');
  const [skills, setSkills] = useState('Marketing, operations, basic coding');
  const [targetIndustry, setTargetIndustry] = useState('Modern B2B Services');

  const [isLoading, setIsLoading] = useState(false);
  const [ideas, setIdeas] = useState<BusinessIdea[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    try {
      const res = await fetch('/api/generate-ideas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          interests,
          budget,
          currency,
          location,
          skills,
          targetIndustry,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate business ideas.');
      }

      setIdeas(data.ideas || []);
    } catch (err: any) {
      console.error('Idea generator error:', err);
      setErrorMessage(err.message || 'Could not generate ideas. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Hero */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
            <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
            AI Idea Incubator
          </span>
          <span className="text-xs text-slate-400">Tailored to your skills & budget</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          AI Business Idea Generator
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
          Discover profitable, modern business opportunities specifically tailored to what you love doing, your capital, and local market demand.
        </p>

        {errorMessage && (
          <div className="mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Input Form */}
        <form onSubmit={handleGenerate} className="mt-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Your Passions, Interests or Hobbies
              </label>
              <input
                type="text"
                value={interests}
                onChange={(e) => setInterests(e.target.value)}
                placeholder="e.g. Specialty coffee, fitness, digital automation, interior design"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                required
              />
              <div className="flex gap-1.5 overflow-x-auto pt-1.5 scrollbar-none">
                {PRESET_INTERESTS.slice(0, 3).map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setInterests(item)}
                    className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 hover:text-white border border-slate-700 shrink-0"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Preferred Industry / Sector
              </label>
              <input
                type="text"
                value={targetIndustry}
                onChange={(e) => setTargetIndustry(e.target.value)}
                placeholder="e.g. Local B2B Services, E-commerce, SaaS, Hospitality"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Starting Budget ({currency})
              </label>
              <div className="flex gap-2">
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-200"
                >
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                  <option value="GBP">GBP</option>
                  <option value="CAD">CAD</option>
                  <option value="AUD">AUD</option>
                  <option value="INR">INR</option>
                  <option value="NGN">NGN</option>
                </select>
                <input
                  type="number"
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-emerald-400 font-mono font-bold"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                City & Country
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Toronto, Canada or London, UK"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-amber-600 to-emerald-600 hover:from-amber-500 hover:to-emerald-500 text-white font-bold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                <span>Brainstorming Viable Concepts...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-200" />
                <span>Generate High-Potential Business Ideas</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Generated Ideas Display */}
      {ideas.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              Generated Opportunities ({ideas.length})
            </h2>
            <span className="text-xs text-slate-400">Click any card to forge its complete business plan</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ideas.map((idea, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-6 transition-all shadow-md flex flex-col justify-between group space-y-4"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div>
                      <h3 className="font-extrabold text-base text-white group-hover:text-emerald-400 transition-colors">
                        {idea.name}
                      </h3>
                      <p className="text-xs text-emerald-400 font-medium italic">{idea.tagline}</p>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700 shrink-0">
                      {idea.businessType}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed mt-2">{idea.summary}</p>

                  <div className="mt-3 pt-3 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-500 block">Est. Startup Cost:</span>
                      <strong className="text-emerald-400 font-mono">{idea.estimatedStartupCost}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Time to 1st Dollar:</span>
                      <strong className="text-teal-400">{idea.timeToFirstDollar || '14-30 days'}</strong>
                    </div>
                  </div>

                  <div className="mt-2 text-xs text-slate-400">
                    <strong className="text-slate-300">Revenue Model:</strong> {idea.monetization}
                  </div>
                </div>

                <button
                  onClick={() =>
                    onUseIdeaInPlan({
                      idea: `${idea.name}: ${idea.summary}`,
                      budget: budget,
                      currency: currency,
                      countryCity: location,
                      skills: skills,
                      businessType: idea.businessType,
                      targetCustomers: idea.targetAudience,
                    })
                  }
                  className="w-full py-2.5 px-4 bg-emerald-600/10 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/30 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 group-hover:shadow-lg"
                >
                  <span>Build Full Business Plan for This Idea</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
