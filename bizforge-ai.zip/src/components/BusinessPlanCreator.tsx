import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  FileText,
  DollarSign,
  MapPin,
  Briefcase,
  Users,
  Building,
  RotateCcw,
  Zap,
  AlertCircle,
  HelpCircle,
  CheckCircle,
  Layers,
} from 'lucide-react';
import { BusinessPlan, BusinessPlanInputs } from '../types';
import { SAMPLE_PLAN } from '../data/samplePlan';
import confetti from 'canvas-confetti';

interface BusinessPlanCreatorProps {
  onPlanGenerated: (plan: BusinessPlan) => void;
  onLoadSample: () => void;
  initialInputs?: Partial<BusinessPlanInputs>;
}

const CURRENCIES = [
  { code: 'USD', symbol: '$', label: 'USD ($)' },
  { code: 'EUR', symbol: '€', label: 'EUR (€)' },
  { code: 'GBP', symbol: '£', label: 'GBP (£)' },
  { code: 'CAD', symbol: 'CA$', label: 'CAD ($)' },
  { code: 'AUD', symbol: 'A$', label: 'AUD ($)' },
  { code: 'INR', symbol: '₹', label: 'INR (₹)' },
  { code: 'NGN', symbol: '₦', label: 'NGN (₦)' },
  { code: 'SGD', symbol: 'S$', label: 'SGD ($)' },
  { code: 'JPY', symbol: '¥', label: 'JPY (¥)' },
];

const BUDGET_PRESETS = [
  { label: 'Bootstrapped', amount: '1000' },
  { label: 'Lean Launch', amount: '3000' },
  { label: 'Standard', amount: '5000' },
  { label: 'Growth', amount: '10000' },
  { label: 'Scale', amount: '25000' },
];

const BUSINESS_TYPES = [
  'Digital Product / SaaS',
  'Local Service / Agency',
  'E-Commerce & DTC Store',
  'Consulting & Professional Services',
  'Brick & Mortar / Hospitality',
  'Marketplace / Platform',
  'Content Creator / Media Brand',
];

const IDEA_SUGGESTIONS = [
  'On-demand mobile pet grooming and organic wellness spa',
  'AI-powered inventory forecasting for independent coffee roasteries',
  'B2B outbound sales agency for climate-tech startups',
  'Eco-friendly modular tiny office pods for remote workers',
  'Specialty gluten-free micro-bakery and weekend subscription box',
  'Virtual CFO and tax advisory for digital nomads and agencies',
];

const SKILL_SUGGESTIONS = [
  'Sales & Marketing',
  'Software Development',
  'Operations & Logistics',
  'Graphic Design & Branding',
  'Hospitality & Customer Care',
  'First-time Founder (Fast Learner)',
];

export const BusinessPlanCreator: React.FC<BusinessPlanCreatorProps> = ({
  onPlanGenerated,
  onLoadSample,
  initialInputs,
}) => {
  const [idea, setIdea] = useState(initialInputs?.idea || '');
  const [countryCity, setCountryCity] = useState(initialInputs?.countryCity || 'Austin, TX, USA');
  const [budget, setBudget] = useState(initialInputs?.budget || '5000');
  const [currency, setCurrency] = useState(initialInputs?.currency || 'USD');
  const [skills, setSkills] = useState(initialInputs?.skills || 'Operations, marketing & client management');
  const [targetCustomers, setTargetCustomers] = useState(
    initialInputs?.targetCustomers || 'Local businesses, tech startups, and busy professionals'
  );
  const [businessType, setBusinessType] = useState(
    initialInputs?.businessType || 'Local Service / Agency'
  );

  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync when initialInputs change
  useEffect(() => {
    if (initialInputs?.idea) setIdea(initialInputs.idea);
    if (initialInputs?.countryCity) setCountryCity(initialInputs.countryCity);
    if (initialInputs?.budget) setBudget(initialInputs.budget);
    if (initialInputs?.currency) setCurrency(initialInputs.currency);
    if (initialInputs?.skills) setSkills(initialInputs.skills);
    if (initialInputs?.targetCustomers) setTargetCustomers(initialInputs.targetCustomers);
    if (initialInputs?.businessType) setBusinessType(initialInputs.businessType);
  }, [initialInputs]);

  // Loading step simulation for realistic progress UX
  useEffect(() => {
    let interval: any;
    if (isLoading) {
      setLoadingStep(0);
      interval = setInterval(() => {
        setLoadingStep((prev) => (prev < 3 ? prev + 1 : prev));
      }, 3500);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  const loadingMessages = [
    'Analyzing target market dynamics, competitor positioning & customer pain points...',
    'Itemizing startup cost estimates & runway burn within your budget...',
    'Architecting monetization tiers, unit economics & customer acquisition strategy...',
    'Finalizing comprehensive 30-day launch roadmap...',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!idea.trim()) {
      setErrorMessage('Please describe your business idea.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('/api/generate-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          idea,
          countryCity,
          budget,
          currency,
          skills,
          targetCustomers,
          businessType,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Failed to generate business plan. Please check your Gemini API key or try again.');
      }

      const generatedData = result.data;
      const fullPlan: BusinessPlan = {
        id: 'plan_' + Date.now(),
        createdAt: new Date().toISOString(),
        inputs: {
          idea,
          countryCity,
          budget,
          currency,
          skills,
          targetCustomers,
          businessType,
        },
        ...generatedData,
      };

      // Trigger celebratory confetti!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#10b981', '#34d399', '#059669', '#38bdf8'],
        });
      } catch (e) {
        // ignore confetti fail
      }

      onPlanGenerated(fullPlan);
    } catch (err: any) {
      console.error('Plan generation error:', err);
      setErrorMessage(err.message || 'Something went wrong while generating the business plan. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePickRandomIdea = () => {
    const random = IDEA_SUGGESTIONS[Math.floor(Math.random() * IDEA_SUGGESTIONS.length)];
    setIdea(random);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Intro hero card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-2xl shadow-emerald-950/10">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl -z-10 pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                AI Business Plan Creator
              </span>
              <span className="text-xs text-slate-400">Model: Gemini 3.8 Flash</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Turn your idea into an actionable business plan.
            </h1>
            <p className="text-sm text-slate-300 mt-1">
              Provide a few key details about your vision, budget, and location. Our AI architect will engineer a complete 9-part investor-grade roadmap.
            </p>
          </div>

          <button
            type="button"
            onClick={onLoadSample}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700/80 transition-all flex items-center gap-2 shrink-0 self-start sm:self-auto hover:border-emerald-500/40"
          >
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>Load Sample Plan</span>
          </button>
        </div>

        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex items-start gap-3">
            <AlertCircle className="w-5 h-5 shrink-0 text-rose-400 mt-0.5" />
            <div className="flex-1">
              <span className="font-bold block mb-0.5">Could not generate plan</span>
              <p>{errorMessage}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 1. Business Idea */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs sm:text-sm font-bold text-slate-200 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                1. What is your business idea? <span className="text-emerald-400">*</span>
              </label>
              <button
                type="button"
                onClick={handlePickRandomIdea}
                className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-medium transition-colors"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Try an example idea</span>
              </button>
            </div>
            <textarea
              rows={3}
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
              placeholder="Describe the product or service you want to launch, what problem it solves, and why people will pay for it..."
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all resize-none"
              required
            />
            {/* Quick Suggestions Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
              <span className="text-slate-500 shrink-0">Inspirations:</span>
              {IDEA_SUGGESTIONS.slice(0, 3).map((item, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setIdea(item)}
                  className="px-2.5 py-1 rounded-full bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 truncate max-w-[200px] shrink-0 transition-colors"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          {/* Row 2: Location and Business Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Country and City */}
            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-bold text-slate-200 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-teal-400" />
                2. Country and City <span className="text-emerald-400">*</span>
              </label>
              <input
                type="text"
                value={countryCity}
                onChange={(e) => setCountryCity(e.target.value)}
                placeholder="e.g. Austin, TX, USA or London, UK"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                required
              />
              <p className="text-[11px] text-slate-500">
                Helps localize legal considerations, competitive density, and currency.
              </p>
            </div>

            {/* Business Type */}
            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-bold text-slate-200 flex items-center gap-2">
                <Building className="w-4 h-4 text-indigo-400" />
                3. Business Type <span className="text-emerald-400">*</span>
              </label>
              <select
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
              >
                {BUSINESS_TYPES.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-500">
                Determines startup capital allocation and delivery model.
              </p>
            </div>
          </div>

          {/* Row 3: Starting Budget & Currency */}
          <div className="space-y-2 p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
            <label className="text-xs sm:text-sm font-bold text-slate-200 flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              4. Starting Budget & Currency <span className="text-emerald-400">*</span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                >
                  {CURRENCIES.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                  Budget Amount ({currency})
                </label>
                <input
                  type="number"
                  min="100"
                  max="10000000"
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                  placeholder="e.g. 5000"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-2 text-sm font-mono text-emerald-400 font-bold focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>
            </div>

            {/* Budget Presets */}
            <div className="flex items-center gap-2 flex-wrap pt-1">
              <span className="text-[11px] text-slate-500">Quick presets:</span>
              {BUDGET_PRESETS.map((p) => (
                <button
                  key={p.amount}
                  type="button"
                  onClick={() => setBudget(p.amount)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors ${
                    budget === p.amount
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {p.label} ({currency} {Number(p.amount).toLocaleString()})
                </button>
              ))}
            </div>
          </div>

          {/* Row 4: Founder Skills & Target Customers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Skills & Experience */}
            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-bold text-slate-200 flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-amber-400" />
                5. Your Skills & Experience
              </label>
              <textarea
                rows={2}
                value={skills}
                onChange={(e) => setSkills(e.target.value)}
                placeholder="e.g. 5 years in retail management, basic web design, strong cold outreach skills..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all resize-none"
              />
              <div className="flex flex-wrap gap-1 pt-0.5">
                {SKILL_SUGGESTIONS.slice(0, 3).map((s, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSkills((prev) => (prev ? `${prev}, ${s}` : s))}
                    className="text-[10px] px-2 py-0.5 rounded bg-slate-800/80 text-slate-400 hover:text-emerald-400 border border-slate-700/60"
                  >
                    + {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Target Customers */}
            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-bold text-slate-200 flex items-center gap-2">
                <Users className="w-4 h-4 text-purple-400" />
                6. Target Customers
              </label>
              <textarea
                rows={2}
                value={targetCustomers}
                onChange={(e) => setTargetCustomers(e.target.value)}
                placeholder="e.g. Local medical practices with 10-50 staff, busy tech workers in downtown Austin..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all resize-none"
              />
              <p className="text-[11px] text-slate-500">
                Helps tailor the persona pain points and top marketing acquisition channels.
              </p>
            </div>
          </div>

          {/* Loading status bar during generation */}
          {isLoading && (
            <div className="p-5 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 space-y-3 animate-fadeIn">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 border-3 border-emerald-500/30 border-t-emerald-400 rounded-full animate-spin shrink-0" />
                <div className="flex-1">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    Forging Your Business Plan
                    <span className="text-xs font-normal text-emerald-400">Step {loadingStep + 1} of 4</span>
                  </h4>
                  <p className="text-xs text-slate-300 mt-0.5 transition-all">
                    {loadingMessages[loadingStep]}
                  </p>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-400 h-full rounded-full transition-all duration-700"
                  style={{ width: `${(loadingStep + 1) * 25}%` }}
                />
              </div>
            </div>
          )}

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-4 px-6 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white font-extrabold text-sm sm:text-base rounded-2xl shadow-xl shadow-emerald-950/50 transition-all flex items-center justify-center gap-2.5 group cursor-pointer"
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  <span>Synthesizing Strategy with Gemini 3.8 Flash...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 text-emerald-200 group-hover:rotate-12 transition-transform" />
                  <span>Generate Complete Business Plan</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
