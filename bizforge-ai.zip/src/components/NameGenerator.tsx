import React, { useState } from 'react';
import {
  Fingerprint,
  Sparkles,
  Copy,
  Check,
  Globe,
  ArrowRight,
  AlertCircle,
  Tag,
} from 'lucide-react';
import { BusinessNameOption, BusinessPlanInputs } from '../types';

interface NameGeneratorProps {
  onUseNameInPlan: (name: string, tagline: string) => void;
}

const STYLES = [
  'Modern & Punchy (e.g. Stripe, Vercel, Shopify)',
  'Trustworthy & Executive (e.g. Vanguard, Apex, Beacon)',
  'Playful & Friendly (e.g. Mailchimp, Bumble, Figma)',
  'Minimalist & Elegant (e.g. Notion, Linear, Calm)',
  'Compound / Evocative (e.g. BizForge, EcoSpark, Firecrawl)',
];

export const NameGenerator: React.FC<NameGeneratorProps> = ({ onUseNameInPlan }) => {
  const [idea, setIdea] = useState('Eco-friendly mobile car detailing and surface protection');
  const [industry, setIndustry] = useState('Automotive Care & Green Services');
  const [style, setStyle] = useState(STYLES[0]);

  const [isLoading, setIsLoading] = useState(false);
  const [names, setNames] = useState<BusinessNameOption[]>([]);
  const [copiedName, setCopiedName] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    try {
      const res = await fetch('/api/generate-names', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idea, industry, style }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate brand names.');
      }

      setNames(data.names || []);
    } catch (err: any) {
      console.error('Name generator error:', err);
      setErrorMessage(err.message || 'Could not generate names. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedName(id);
    setTimeout(() => setCopiedName(null), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Hero */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30 flex items-center gap-1.5">
            <Fingerprint className="w-3.5 h-3.5 text-teal-400" />
            Brand Naming Studio
          </span>
          <span className="text-xs text-slate-400">Memorable, brandable & domain-ready</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          Business Name & Domain Generator
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
          Generate memorable, trademark-friendly brand names, taglines, and domain suggestions crafted to stand out in your target market.
        </p>

        {errorMessage && (
          <div className="mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Inputs */}
        <form onSubmit={handleGenerate} className="mt-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Your Business Concept or Keywords
              </label>
              <input
                type="text"
                value={idea}
                onChange={(e) => setIdea(e.target.value)}
                placeholder="e.g. AI-driven financial modeling for freelancers"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Industry</label>
              <input
                type="text"
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                placeholder="e.g. FinTech, Coffee, Real Estate"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="sm:col-span-3">
              <label className="text-xs font-semibold text-slate-300 block mb-1">Naming Style</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {STYLES.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setStyle(s)}
                    className={`px-3 py-2 rounded-xl text-left text-xs border transition-all ${
                      style === s
                        ? 'bg-teal-950/60 border-teal-500 text-teal-300 font-semibold'
                        : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                <span>Crafting Brand Identities...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-teal-200" />
                <span>Generate Brand Names</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Results Grid */}
      {names.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-100">Suggested Brand Names ({names.length})</h2>
            <span className="text-xs text-slate-400">Click "Use in Plan" to apply name to your plan</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {names.map((item, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 hover:border-teal-500/40 rounded-2xl p-5 transition-all shadow-sm flex flex-col justify-between group space-y-3"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-extrabold text-lg text-white group-hover:text-teal-400 transition-colors">
                      {item.name}
                    </h3>
                    <button
                      onClick={() => handleCopy(`${item.name} - ${item.tagline}`, `name_${idx}`)}
                      className="text-slate-500 hover:text-slate-200 p-1"
                      title="Copy Name & Tagline"
                    >
                      {copiedName === `name_${idx}` ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  <p className="text-xs text-emerald-400 font-medium italic mt-0.5">"{item.tagline}"</p>

                  <div className="flex items-center gap-2 mt-3 text-xs">
                    <span className="flex items-center gap-1 font-mono text-teal-300 bg-teal-950/40 border border-teal-500/20 px-2 py-0.5 rounded">
                      <Globe className="w-3 h-3 text-teal-400" />
                      {item.domainSuggestion}
                    </span>
                    <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                      {item.vibe || item.styleCategory}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">{item.rationale}</p>
                </div>

                <button
                  onClick={() => onUseNameInPlan(item.name, item.tagline)}
                  className="w-full py-2 px-3 bg-teal-600/10 hover:bg-teal-600 text-teal-300 hover:text-white border border-teal-500/30 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5"
                >
                  <span>Use in Business Plan</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
