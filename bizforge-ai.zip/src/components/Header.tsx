import React, { useState } from 'react';
import {
  Sparkles,
  FileText,
  Calculator,
  Lightbulb,
  Megaphone,
  Fingerprint,
  CalendarCheck2,
  Menu,
  X,
  ShieldAlert,
  Flame,
  Bookmark,
  ChevronDown,
  User,
  CreditCard,
  LogIn,
} from 'lucide-react';
import { BusinessPlan } from '../types';
import { useAuth } from '../context/AuthContext';

export type ActiveTab =
  | 'plan-creator'
  | 'calculator'
  | 'ideas'
  | 'marketing'
  | 'names'
  | 'launch-roadmap';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  savedPlans: BusinessPlan[];
  activePlan: BusinessPlan | null;
  onSelectPlan: (plan: BusinessPlan) => void;
  onOpenFeedbackReview: () => void;
  feedbackCount: number;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onOpenPayment: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  savedPlans,
  activePlan,
  onSelectPlan,
  onOpenFeedbackReview,
  feedbackCount,
  onOpenAuth,
  onOpenProfile,
  onOpenPayment,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [plansDropdownOpen, setPlansDropdownOpen] = useState(false);

  const { user, profile } = useAuth();

  const navItems = [
    {
      id: 'plan-creator' as ActiveTab,
      label: 'AI Plan Creator',
      icon: FileText,
      badge: 'Core Priority',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    },
    {
      id: 'calculator' as ActiveTab,
      label: 'Profit Calculator',
      icon: Calculator,
    },
    {
      id: 'ideas' as ActiveTab,
      label: 'Idea Generator',
      icon: Lightbulb,
    },
    {
      id: 'marketing' as ActiveTab,
      label: 'Marketing Kit',
      icon: Megaphone,
    },
    {
      id: 'names' as ActiveTab,
      label: 'Name Generator',
      icon: Fingerprint,
    },
    {
      id: 'launch-roadmap' as ActiveTab,
      label: '30-Day Launch',
      icon: CalendarCheck2,
    },
  ];

  const getTierLabel = () => {
    const tier = profile?.subscriptionTier || 'free';
    if (tier === 'pro') return 'PRO';
    if (tier === 'starter') return 'STARTER';
    if (tier === 'unlimited') return 'AGENCY';
    return 'FREE';
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-900/95 backdrop-blur-md border-b border-slate-800 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-18">
          {/* Logo & Tagline */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('plan-creator')}
              className="flex items-center gap-2.5 text-left group focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform">
                <Flame className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-xl tracking-tight text-white font-['Plus_Jakarta_Sans']">
                    Biz<span className="text-emerald-400">Forge</span>
                  </span>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    AI
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 hidden sm:block">
                  Turn your idea into a business.
                </p>
              </div>
            </button>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden xl:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-slate-800 text-white shadow-sm border border-slate-700/80'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-emerald-400' : 'text-slate-400'
                    }`}
                  />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded font-bold border uppercase tracking-wider ${item.badgeColor}`}
                    >
                      {item.badge}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-3 right-3 h-0.5 bg-emerald-400 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action buttons */}
          <div className="hidden sm:flex items-center gap-2">
            {/* Pricing / Upgrade Button */}
            <button
              onClick={onOpenPayment}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 transition-all shadow-sm"
              title="View pricing plans & payment options"
            >
              <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
              <span>Pricing</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500 text-slate-950 font-extrabold uppercase">
                Pro
              </span>
            </button>

            {/* Saved Plans selector */}
            {savedPlans.length > 0 && (
              <div className="relative">
                <button
                  onClick={() => setPlansDropdownOpen(!plansDropdownOpen)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-slate-800/80 border border-slate-700/80 text-slate-300 hover:text-white transition-colors"
                >
                  <Bookmark className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="truncate max-w-[90px]">
                    {activePlan ? activePlan.businessName : 'Plans'}
                  </span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {plansDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-xl shadow-xl py-2 z-50 text-xs">
                    <div className="px-3 py-1 font-semibold text-slate-400 border-b border-slate-800 mb-1">
                      Your Business Plans ({savedPlans.length})
                    </div>
                    <div className="max-h-60 overflow-y-auto">
                      {savedPlans.map((plan) => (
                        <button
                          key={plan.id}
                          onClick={() => {
                            onSelectPlan(plan);
                            setPlansDropdownOpen(false);
                            setActiveTab('plan-creator');
                          }}
                          className={`w-full text-left px-3 py-2 flex flex-col hover:bg-slate-800 transition-colors ${
                            activePlan?.id === plan.id
                              ? 'bg-slate-800/90 text-emerald-400 font-semibold'
                              : 'text-slate-300'
                          }`}
                        >
                          <span className="truncate">{plan.businessName}</span>
                          <span className="text-[10px] text-slate-500">
                            {plan.inputs.countryCity || 'Global'} • {new Date(plan.createdAt).toLocaleDateString()}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Feedback Review Badge */}
            <button
              onClick={onOpenFeedbackReview}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-slate-800/60 border border-slate-700/60 text-slate-300 hover:text-emerald-400 transition-colors"
              title="Audit and review user feedback on AI plans"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-emerald-400" />
              {feedbackCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-emerald-500 text-slate-950">
                  {feedbackCount}
                </span>
              )}
            </button>

            {/* User Profile / Auth Button */}
            {user ? (
              <button
                onClick={onOpenProfile}
                className="flex items-center gap-2 pl-2 pr-3 py-1 rounded-xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700 text-xs transition-colors"
                title="Account & Profile Settings"
              >
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-300 font-bold text-[11px]">
                  {profile?.displayName
                    ? profile.displayName.charAt(0).toUpperCase()
                    : user.email?.charAt(0).toUpperCase() || 'U'}
                </div>
                <div className="flex flex-col text-left">
                  <span className="font-semibold text-slate-200 truncate max-w-[80px]">
                    {profile?.displayName || 'Profile'}
                  </span>
                </div>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold uppercase">
                  {getTierLabel()}
                </span>
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-950/40"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
            )}
          </div>

          {/* Mobile buttons */}
          <div className="flex items-center gap-2 lg:hidden">
            {user ? (
              <button
                onClick={onOpenProfile}
                className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 text-xs font-bold"
                aria-label="User Profile"
              >
                {profile?.displayName?.charAt(0).toUpperCase() || 'U'}
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-2.5 py-1 bg-emerald-600 text-white text-xs font-bold rounded-lg"
              >
                Sign In
              </button>
            )}

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-lg focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-800 bg-slate-900/98 px-4 pt-3 pb-6 space-y-3 animate-fadeIn">
          {/* Mobile User Profile Bar */}
          {user ? (
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-xs">
                  {profile?.displayName?.charAt(0).toUpperCase() || 'U'}
                </div>
                <div>
                  <div className="font-bold text-xs text-white">{profile?.displayName || 'Founder'}</div>
                  <div className="text-[10px] text-slate-400 truncate max-w-[140px]">{user.email}</div>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenProfile();
                  }}
                  className="px-2.5 py-1 rounded bg-slate-800 text-xs text-slate-200 border border-slate-700"
                >
                  Settings
                </button>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenPayment();
                  }}
                  className="px-2.5 py-1 rounded bg-emerald-600 text-xs text-white font-bold"
                >
                  Upgrade
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAuth();
              }}
              className="w-full py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              <span>Create Account or Sign In</span>
            </button>
          )}

          <div className="text-[11px] font-bold tracking-wider text-slate-400 uppercase px-2">
            BizForge Tools
          </div>
          <div className="grid grid-cols-1 gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-slate-800 text-emerald-400 border border-slate-700'
                      : 'text-slate-300 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="pt-2 flex items-center gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenPayment();
              }}
              className="flex-1 py-2 rounded-xl bg-emerald-600/20 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5"
            >
              <CreditCard className="w-4 h-4" />
              <span>View Pricing Plans</span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenFeedbackReview();
              }}
              className="py-2 px-3 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 text-xs flex items-center justify-center gap-1"
            >
              <ShieldAlert className="w-4 h-4 text-emerald-400" />
              <span>Logs ({feedbackCount})</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
