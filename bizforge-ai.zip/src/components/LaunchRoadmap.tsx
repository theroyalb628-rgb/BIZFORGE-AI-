import React, { useState, useEffect } from 'react';
import {
  CalendarCheck2,
  CheckCircle2,
  Circle,
  Sparkles,
  Download,
  Copy,
  Check,
  Plus,
  Filter,
  Layers,
  ArrowRight,
  AlertCircle,
  Flag,
} from 'lucide-react';
import { BusinessPlan, LaunchDayTask } from '../types';

interface LaunchRoadmapProps {
  activePlan: BusinessPlan | null;
}

export const LaunchRoadmap: React.FC<LaunchRoadmapProps> = ({ activePlan }) => {
  const [selectedWeek, setSelectedWeek] = useState<number | 'all'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [copied, setCopied] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDay, setNewTaskDay] = useState('Day 1');
  const [newTaskCategory, setNewTaskCategory] = useState('Operations');
  const [showAddModal, setShowAddModal] = useState(false);

  // Extract tasks from activePlan or initialize default 30-day tasks
  const [tasks, setTasks] = useState<LaunchDayTask[]>(() => {
    if (activePlan?.launchPlan30Day?.weeks) {
      const flattened: LaunchDayTask[] = [];
      let dayCounter = 1;
      activePlan.launchPlan30Day.weeks.forEach((w) => {
        w.tasks.forEach((t) => {
          flattened.push({
            dayNumber: dayCounter++,
            title: `[${t.dayRange}] ${t.title}`,
            category: w.theme.includes('Legal') ? 'Legal' : w.theme.includes('Marketing') ? 'Marketing' : 'Product',
            description: t.description,
            checklistItems: t.deliverable ? [t.deliverable] : ['Complete assigned milestone'],
            completed: false,
          });
        });
      });
      return flattened;
    }

    // Default template tasks
    return [
      { dayNumber: 1, title: 'Day 1-2: Business Registration & Tax ID', category: 'Legal', description: 'File LLC / corporation paperwork and obtain federal EIN.', checklistItems: ['File certificate of formation', 'Obtain federal tax ID (EIN)'], completed: false },
      { dayNumber: 2, title: 'Day 3-4: Dedicated Bank Account & Stripe', category: 'Finance', description: 'Set up business checking and payment gateway integration.', checklistItems: ['Open zero-fee business checking account', 'Configure Stripe / payment processor'], completed: false },
      { dayNumber: 3, title: 'Day 5-7: Core Value Proposition & Pricing', category: 'Product', description: 'Lock in 3 service tiers and test pricing with 5 prospective buyers.', checklistItems: ['Finalize 1-page pricing sheet', 'Conduct 3 customer discovery calls'], completed: false },
      { dayNumber: 4, title: 'Day 8-10: High-Converting Landing Page', category: 'Product', description: 'Deploy responsive landing page with customer testimonials & lead capture.', checklistItems: ['Connect custom domain and SSL', 'Setup Calendly / booking flow'], completed: false },
      { dayNumber: 5, title: 'Day 11-13: Standard Operating Procedures (SOPs)', category: 'Operations', description: 'Draft step-by-step fulfillment and client onboarding checklist.', checklistItems: ['Draft onboarding welcome email template', 'Create client contract agreements'], completed: false },
      { dayNumber: 6, title: 'Day 14-17: Lead Generation & Cold Outreach', category: 'Marketing', description: 'Build list of 100 qualified prospects and initiate personalized outreach.', checklistItems: ['Scrape 100 targeted LinkedIn leads', 'Launch 3-touch cold email sequence'], completed: false },
      { dayNumber: 7, title: 'Day 18-21: Local SEO & Google Business Profile', category: 'Marketing', description: 'Optimize local search visibility and request launch badges.', checklistItems: ['Submit Google Business profile', 'Publish 3 targeted social launch hooks'], completed: false },
      { dayNumber: 8, title: 'Day 22-25: Pitch Meetings & Proposal Submissions', category: 'Sales', description: 'Conduct discovery walkthroughs and send proposals within 6 hours.', checklistItems: ['Conduct 5 prospect discovery calls', 'Send out 3 tailored proposals'], completed: false },
      { dayNumber: 9, title: 'Day 26-28: Sign First Paying Customers', category: 'Sales', description: 'Close initial 2-3 paying clients with first-month satisfaction guarantee.', checklistItems: ['Collect first payment deposit', 'Send client onboarding kit'], completed: false },
      { dayNumber: 10, title: 'Day 29-30: Fulfillment Review & Referral Engine', category: 'Operations', description: 'Deliver impeccable initial service and request testimonial reviews.', checklistItems: ['Send post-service satisfaction survey', 'Ask for 1 referral intro'], completed: false },
    ];
  });

  // Re-sync if plan changes
  useEffect(() => {
    if (activePlan?.launchPlan30Day?.weeks) {
      const flattened: LaunchDayTask[] = [];
      let counter = 1;
      activePlan.launchPlan30Day.weeks.forEach((w) => {
        w.tasks.forEach((t) => {
          flattened.push({
            dayNumber: counter++,
            title: `[${t.dayRange}] ${t.title}`,
            category: w.theme.includes('Legal') ? 'Legal' : w.theme.includes('Marketing') ? 'Marketing' : 'Product',
            description: t.description,
            checklistItems: t.deliverable ? [t.deliverable] : ['Verify milestone completion'],
            completed: !!t.completed,
          });
        });
      });
      setTasks(flattened);
    }
  }, [activePlan]);

  const toggleTask = (index: number) => {
    setTasks((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], completed: !updated[index].completed };
      return updated;
    });
  };

  const completedCount = tasks.filter((t) => t.completed).length;
  const progressPercent = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  const filteredTasks = tasks.filter((task) => {
    if (selectedCategory !== 'all' && task.category !== selectedCategory) return false;
    if (selectedWeek !== 'all') {
      const weekIndex = Math.ceil(task.dayNumber / Math.ceil(tasks.length / 4));
      if (weekIndex !== selectedWeek) return false;
    }
    return true;
  });

  const handleCopyChecklist = () => {
    const text = `# 30-Day Business Launch Roadmap
Progress: ${completedCount}/${tasks.length} tasks completed (${progressPercent}%)

${tasks
  .map(
    (t) =>
      `- [${t.completed ? 'x' : ' '}] ${t.title} (${t.category})\n  ${t.description}\n  Deliverable: ${t.checklistItems.join(', ')}`
  )
  .join('\n\n')}
`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    const newTask: LaunchDayTask = {
      dayNumber: tasks.length + 1,
      title: `${newTaskDay}: ${newTaskTitle.trim()}`,
      category: newTaskCategory,
      description: 'Custom founder milestone added to launch plan.',
      checklistItems: ['Execute and verify deliverable'],
      completed: false,
    };

    setTasks([...tasks, newTask]);
    setNewTaskTitle('');
    setShowAddModal(false);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Hero */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
                <CalendarCheck2 className="w-3.5 h-3.5 text-amber-400" />
                Execution Roadmap
              </span>
              {activePlan && (
                <span className="text-xs text-slate-400">
                  Business: <strong className="text-emerald-400">{activePlan.businessName}</strong>
                </span>
              )}
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
              30-Day Business Launch Planner
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Turn abstract goals into daily execution. Track your legal foundation, MVP build, pre-launch traction, and closing your first customers.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddModal(true)}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4 text-emerald-400" />
              <span>Add Custom Task</span>
            </button>

            <button
              onClick={handleCopyChecklist}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied' : 'Export Checklist'}</span>
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-medium">
              Launch Readiness Progress: <strong className="text-emerald-400">{completedCount} of {tasks.length} tasks completed</strong>
            </span>
            <span className="text-sm font-extrabold text-emerald-400 font-mono">
              {progressPercent}%
            </span>
          </div>
          <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-3.5 rounded-2xl text-xs">
        {/* Weeks Filter */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-slate-500 font-semibold mr-1">Phase:</span>
          {(['all', 1, 2, 3, 4] as const).map((w) => (
            <button
              key={w}
              onClick={() => setSelectedWeek(w)}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                selectedWeek === w
                  ? 'bg-emerald-500 text-slate-950 font-bold'
                  : 'bg-slate-800/60 text-slate-400 hover:text-white'
              }`}
            >
              {w === 'all' ? 'All 30 Days' : `Week ${w}`}
            </button>
          ))}
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-2">
          <span className="text-slate-500">Track:</span>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="all">All Disciplines</option>
            <option value="Legal">Legal & Setup</option>
            <option value="Product">Product & Tech</option>
            <option value="Marketing">Marketing & Launch</option>
            <option value="Sales">Sales & Outreach</option>
            <option value="Operations">Operations</option>
            <option value="Finance">Finance</option>
          </select>
        </div>
      </div>

      {/* Task Checklist Items */}
      <div className="space-y-3">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl text-slate-400">
            No tasks match this filter.
          </div>
        ) : (
          filteredTasks.map((task, idx) => {
            const originalIndex = tasks.findIndex((t) => t.title === task.title);
            return (
              <div
                key={idx}
                onClick={() => toggleTask(originalIndex)}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                  task.completed
                    ? 'bg-emerald-950/20 border-emerald-500/30 text-slate-400'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-100'
                }`}
              >
                <button
                  type="button"
                  className="mt-0.5 shrink-0 focus:outline-none"
                  aria-label="Toggle task completion"
                >
                  {task.completed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Circle className="w-5 h-5 text-slate-600 hover:text-emerald-400" />
                  )}
                </button>

                <div className="flex-1">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span
                      className={`text-sm font-bold ${
                        task.completed ? 'line-through text-slate-400' : 'text-slate-100'
                      }`}
                    >
                      {task.title}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-slate-800 text-slate-400 border border-slate-700/60">
                      {task.category}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed mb-2">{task.description}</p>

                  {task.checklistItems && task.checklistItems.length > 0 && (
                    <div className="flex items-center gap-2 flex-wrap text-[11px] text-slate-400">
                      <span className="text-emerald-400 font-semibold">Key Deliverable:</span>
                      {task.checklistItems.map((item, itemIdx) => (
                        <span key={itemIdx} className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                          🎯 {item}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add Custom Task Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full space-y-4">
            <h3 className="font-bold text-base text-slate-100">Add Milestone to 30-Day Plan</h3>
            <form onSubmit={handleAddTask} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-medium block mb-1">Day / Timeframe</label>
                <input
                  type="text"
                  value={newTaskDay}
                  onChange={(e) => setNewTaskDay(e.target.value)}
                  placeholder="e.g. Day 12 or Day 15-16"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100"
                  required
                />
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Milestone Title</label>
                <input
                  type="text"
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  placeholder="e.g. Finalize manufacturer agreement"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100"
                  required
                />
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Discipline Category</label>
                <select
                  value={newTaskCategory}
                  onChange={(e) => setNewTaskCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100"
                >
                  <option value="Legal">Legal</option>
                  <option value="Product">Product</option>
                  <option value="Marketing">Marketing</option>
                  <option value="Sales">Sales</option>
                  <option value="Operations">Operations</option>
                  <option value="Finance">Finance</option>
                </select>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold"
                >
                  Save Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
