import React, { useState, useEffect } from 'react';
import {
  Calculator,
  DollarSign,
  TrendingUp,
  PieChart,
  ArrowUpRight,
  ShieldAlert,
  Sparkles,
  Layers,
  Info,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';
import { BusinessPlan } from '../types';

interface ProfitCalculatorProps {
  activePlan: BusinessPlan | null;
}

export const ProfitCalculator: React.FC<ProfitCalculatorProps> = ({ activePlan }) => {
  // Inputs
  const [currency, setCurrency] = useState('USD');
  const [sellingPrice, setSellingPrice] = useState<number>(120);
  const [cogs, setCogs] = useState<number>(35);
  const [monthlyUnits, setMonthlyUnits] = useState<number>(45);
  const [initialInvestment, setInitialInvestment] = useState<number>(5000);
  
  // Fixed costs
  const [softwareTools, setSoftwareTools] = useState<number>(150);
  const [marketingBudget, setMarketingBudget] = useState<number>(600);
  const [rentOrSpace, setRentOrSpace] = useState<number>(0);
  const [contractorWages, setContractorWages] = useState<number>(500);
  const [miscOverhead, setMiscOverhead] = useState<number>(150);

  // Auto populate if activePlan exists
  useEffect(() => {
    if (activePlan) {
      setCurrency(activePlan.startupCosts.currency || 'USD');
      if (activePlan.startupCosts.totalEstimatedBudget) {
        setInitialInvestment(activePlan.startupCosts.totalEstimatedBudget);
      }
      // Infer price from first offering
      const firstPriceStr = activePlan.productsAndServices.offerings[0]?.priceEstimate || '';
      const match = firstPriceStr.match(/(\d+[\d,]*)/);
      if (match) {
        const val = parseInt(match[1].replace(/,/g, ''), 10);
        if (val && !isNaN(val)) setSellingPrice(val);
      }
    }
  }, [activePlan]);

  // Calculations
  const unitMargin = Math.max(0, sellingPrice - cogs);
  const marginPercentage = sellingPrice > 0 ? ((unitMargin / sellingPrice) * 100).toFixed(1) : '0';
  
  const monthlyRevenue = sellingPrice * monthlyUnits;
  const monthlyCOGS = cogs * monthlyUnits;
  const totalFixedCosts = softwareTools + marketingBudget + rentOrSpace + contractorWages + miscOverhead;
  const totalMonthlyExpenses = monthlyCOGS + totalFixedCosts;
  
  const monthlyGrossProfit = monthlyRevenue - monthlyCOGS;
  const monthlyNetProfit = monthlyRevenue - totalMonthlyExpenses;
  const annualNetProfit = monthlyNetProfit * 12;

  // Break-even
  const breakEvenUnits = unitMargin > 0 ? Math.ceil(totalFixedCosts / unitMargin) : 0;
  const breakEvenRevenue = breakEvenUnits * sellingPrice;

  // Payback period
  const paybackMonths =
    monthlyNetProfit > 0
      ? (initialInvestment / monthlyNetProfit).toFixed(1)
      : 'N/A (Net negative)';

  // 12-Month Projections (with modest 5% compound growth per month)
  const projectionMonths = Array.from({ length: 12 }, (_, i) => {
    const month = i + 1;
    const growthFactor = Math.pow(1.06, i); // 6% monthly growth
    const projectedUnits = Math.round(monthlyUnits * growthFactor);
    const rev = projectedUnits * sellingPrice;
    const exp = projectedUnits * cogs + totalFixedCosts;
    const net = rev - exp;
    return {
      month: `M${month}`,
      units: projectedUnits,
      revenue: Math.round(rev),
      expenses: Math.round(exp),
      netProfit: Math.round(net),
    };
  });

  const maxRevenue = Math.max(...projectionMonths.map((m) => m.revenue), 1);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                <Calculator className="w-3.5 h-3.5" />
                Financial Modeling
              </span>
              {activePlan && (
                <span className="text-xs text-slate-400">
                  Linked: <strong className="text-emerald-400">{activePlan.businessName}</strong>
                </span>
              )}
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
              Business Profit & Break-Even Calculator
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Model your unit economics, profit margins, monthly runway, break-even point, and 12-month financial projections in real-time.
            </p>
          </div>

          {activePlan && (
            <button
              onClick={() => {
                setInitialInvestment(activePlan.startupCosts.totalEstimatedBudget);
                setCurrency(activePlan.startupCosts.currency || 'USD');
              }}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 flex items-center gap-2 transition-colors self-start sm:self-auto shrink-0"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset to Plan Figures</span>
            </button>
          )}
        </div>
      </div>

      {/* KPI Highlights Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl space-y-1">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            Gross Margin
          </span>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400">
            {marginPercentage}%
          </div>
          <span className="text-[11px] text-slate-400">
            {currency} {unitMargin} profit / unit
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl space-y-1">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            Monthly Net Profit
          </span>
          <div
            className={`text-2xl sm:text-3xl font-extrabold ${
              monthlyNetProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {currency} {monthlyNetProfit.toLocaleString()}
          </div>
          <span className="text-[11px] text-slate-400">
            Annual: {currency} {annualNetProfit.toLocaleString()}
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl space-y-1">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            Monthly Break-Even
          </span>
          <div className="text-2xl sm:text-3xl font-extrabold text-teal-400">
            {breakEvenUnits} <span className="text-xs font-normal text-slate-400">units</span>
          </div>
          <span className="text-[11px] text-slate-400">
            {currency} {breakEvenRevenue.toLocaleString()} in revenue
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl space-y-1">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            Startup Payback Time
          </span>
          <div className="text-2xl sm:text-3xl font-extrabold text-amber-400">
            {paybackMonths} {monthlyNetProfit > 0 ? 'mo' : ''}
          </div>
          <span className="text-[11px] text-slate-400">
            Initial capital: {currency} {initialInvestment.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Main Inputs Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Unit Economics & Sales Volume */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-slate-100 text-base">Unit Economics & Sales Targets</h3>
          </div>

          {/* Unit Price */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-semibold text-slate-300">
              <label>Average Selling Price per Unit / Client</label>
              <span className="text-emerald-400 font-mono font-bold">
                {currency} {sellingPrice}
              </span>
            </div>
            <input
              type="range"
              min="5"
              max="2000"
              step="5"
              value={sellingPrice}
              onChange={(e) => setSellingPrice(Number(e.target.value))}
              className="w-full accent-emerald-500 bg-slate-950 h-2 rounded-lg"
            />
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Manual input:</span>
              <input
                type="number"
                value={sellingPrice}
                onChange={(e) => setSellingPrice(Math.max(1, Number(e.target.value)))}
                className="w-28 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-100 font-mono"
              />
            </div>
          </div>

          {/* Cost per unit (COGS) */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-semibold text-slate-300">
              <label>Cost of Goods Sold (COGS) / Direct Labor per Unit</label>
              <span className="text-rose-400 font-mono font-bold">
                {currency} {cogs}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max={Math.max(100, sellingPrice)}
              step="5"
              value={cogs}
              onChange={(e) => setCogs(Number(e.target.value))}
              className="w-full accent-emerald-500 bg-slate-950 h-2 rounded-lg"
            />
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Manual input:</span>
              <input
                type="number"
                value={cogs}
                onChange={(e) => setCogs(Math.max(0, Number(e.target.value)))}
                className="w-28 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-100 font-mono"
              />
            </div>
          </div>

          {/* Monthly Sales Volume */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-semibold text-slate-300">
              <label>Expected Monthly Units / Paying Clients</label>
              <span className="text-teal-400 font-mono font-bold">
                {monthlyUnits} units
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="500"
              step="1"
              value={monthlyUnits}
              onChange={(e) => setMonthlyUnits(Number(e.target.value))}
              className="w-full accent-emerald-500 bg-slate-950 h-2 rounded-lg"
            />
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Manual input:</span>
              <input
                type="number"
                value={monthlyUnits}
                onChange={(e) => setMonthlyUnits(Math.max(1, Number(e.target.value)))}
                className="w-28 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-100 font-mono"
              />
            </div>
          </div>

          {/* Initial Capital */}
          <div className="pt-2 border-t border-slate-800 space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 block">
              Initial Startup Capital / Investment ({currency})
            </label>
            <input
              type="number"
              value={initialInvestment}
              onChange={(e) => setInitialInvestment(Math.max(0, Number(e.target.value)))}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 font-mono"
            />
          </div>
        </div>

        {/* Monthly Fixed Overhead Costs */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <PieChart className="w-5 h-5 text-teal-400" />
              <h3 className="font-bold text-slate-100 text-base">Monthly Fixed Overhead</h3>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400">
              Total: {currency} {totalFixedCosts.toLocaleString()} / mo
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-slate-400 font-medium block mb-1">Software, Hosting & Tools</label>
              <input
                type="number"
                value={softwareTools}
                onChange={(e) => setSoftwareTools(Math.max(0, Number(e.target.value)))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="text-slate-400 font-medium block mb-1">Marketing & Ad Spend</label>
              <input
                type="number"
                value={marketingBudget}
                onChange={(e) => setMarketingBudget(Math.max(0, Number(e.target.value)))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="text-slate-400 font-medium block mb-1">Rent / Co-working Space</label>
              <input
                type="number"
                value={rentOrSpace}
                onChange={(e) => setRentOrSpace(Math.max(0, Number(e.target.value)))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="text-slate-400 font-medium block mb-1">Staff / Contractor Payroll</label>
              <input
                type="number"
                value={contractorWages}
                onChange={(e) => setContractorWages(Math.max(0, Number(e.target.value)))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="text-slate-400 font-medium block mb-1">Insurance & Misc Reserves</label>
              <input
                type="number"
                value={miscOverhead}
                onChange={(e) => setMiscOverhead(Math.max(0, Number(e.target.value)))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 font-mono"
              />
            </div>
          </div>

          {/* Quick Summary Statement */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 text-xs text-slate-300 space-y-1.5">
            <div className="font-semibold text-slate-200">Financial Health Check:</div>
            <p>
              To cover your monthly fixed overhead of{' '}
              <strong className="text-emerald-400">
                {currency} {totalFixedCosts.toLocaleString()}
              </strong>
              , you must sell at least <strong className="text-white">{breakEvenUnits} units</strong> per month.
              Every unit sold beyond {breakEvenUnits} generates{' '}
              <strong className="text-emerald-400">
                {currency} {unitMargin}
              </strong>{' '}
              in pure profit.
            </p>
          </div>
        </div>
      </div>

      {/* 12-Month Projections Visualization */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-slate-100 text-base">12-Month Projected Growth Trajectory</h3>
          </div>
          <span className="text-xs text-slate-400">Assuming steady 6% monthly compound acquisition</span>
        </div>

        {/* Visual Bar Chart */}
        <div className="pt-4 pb-2">
          <div className="flex items-end gap-2 h-44 border-b border-slate-800 pb-2">
            {projectionMonths.map((m, idx) => {
              const heightPercent = Math.min(100, Math.max(10, Math.round((m.revenue / maxRevenue) * 100)));
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1 group relative">
                  {/* Tooltip */}
                  <div className="absolute -top-12 bg-slate-950 border border-slate-700 text-white text-[10px] py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-20 pointer-events-none shadow-lg">
                    {m.month}: Rev {currency} {m.revenue.toLocaleString()} | Net {currency} {m.netProfit.toLocaleString()}
                  </div>

                  <div className="w-full flex items-end justify-center h-36">
                    <div
                      className="w-full max-w-[28px] bg-emerald-500 rounded-t-md group-hover:bg-emerald-400 transition-all duration-300"
                      style={{ height: `${heightPercent}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-semibold text-slate-400">{m.month}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Mini Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="py-2 px-3">Timeline</th>
                <th className="py-2 px-3">Projected Units</th>
                <th className="py-2 px-3">Gross Revenue</th>
                <th className="py-2 px-3">Total Costs</th>
                <th className="py-2 px-3 text-right">Net Profit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {[0, 2, 5, 8, 11].map((idx) => {
                const m = projectionMonths[idx];
                return (
                  <tr key={idx} className="hover:bg-slate-800/30">
                    <td className="py-2 px-3 font-semibold text-slate-200">Month {idx + 1}</td>
                    <td className="py-2 px-3 text-slate-300">{m.units} units</td>
                    <td className="py-2 px-3 text-emerald-400 font-mono">
                      {currency} {m.revenue.toLocaleString()}
                    </td>
                    <td className="py-2 px-3 text-slate-400 font-mono">
                      {currency} {m.expenses.toLocaleString()}
                    </td>
                    <td
                      className={`py-2 px-3 text-right font-mono font-bold ${
                        m.netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {currency} {m.netProfit.toLocaleString()}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
