import React, { useState } from 'react';
import {
  X,
  Check,
  CreditCard,
  ShieldCheck,
  Sparkles,
  Zap,
  Lock,
  ArrowRight,
  CheckCircle2,
  Calendar,
  Layers,
  Download,
  Printer,
  BadgeCheck,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { PricingPlan, SubscriptionPayment, SubscriptionTierType } from '../types';
import confetti from 'canvas-confetti';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPlanId?: SubscriptionTierType;
  onOpenAuth: () => void;
}

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'free',
    name: 'Free Founder',
    priceMonthly: 0,
    priceYearly: 0,
    tagline: 'Start validating your concept',
    description: 'Perfect for exploring business ideas and testing unit economics.',
    features: [
      '3 Complete AI Business Plans',
      'Basic Profit & Break-Even Calculator',
      'Business Name Generator',
      'Markdown Plan Export',
      'Community Launch Support',
    ],
    buttonText: 'Current Plan',
  },
  {
    id: 'starter',
    name: 'Starter Builder',
    priceMonthly: 19,
    priceYearly: 15,
    tagline: 'Launch your first venture',
    description: 'Everything you need to plan, model unit economics, and launch lean.',
    features: [
      '15 AI Business Plans per month',
      'Full 12-Month Profit Projection Modeler',
      'AI Marketing Launch Kit & Social Hooks',
      'Interactive 30-Day Launch Roadmap',
      'Inline Plan Editing & Custom Sections',
      'Direct PDF & Print Export',
    ],
    buttonText: 'Upgrade to Starter',
  },
  {
    id: 'pro',
    name: 'Pro Venture',
    priceMonthly: 49,
    priceYearly: 39,
    popular: true,
    tagline: 'For serious founders & creators',
    description: 'Unlimited planning, fast execution models, and complete marketing assets.',
    features: [
      'Unlimited AI Business Plans',
      'Priority Gemini 3.8 Flash Generation',
      'Complete 3-Part Email Sequences & Ad Copy',
      'Investor-Ready Financial Model Exports',
      'Custom Milestone Task Tracker',
      'Multi-currency & Local Sizing Insights',
      'Priority Email & Strategy Support',
    ],
    buttonText: 'Upgrade to Pro Venture',
  },
  {
    id: 'unlimited',
    name: 'Agency Unlimited',
    priceMonthly: 99,
    priceYearly: 79,
    tagline: 'For consultants & incubators',
    description: 'White-label reports and multi-client startup roadmaps.',
    features: [
      'Everything in Pro Venture',
      'White-Label PDF Reports (No BizForge watermark)',
      'Multiple Business Entity Profiles',
      'Dedicated Strategy Advisor Review',
      'Early Access to New Venture Models',
    ],
    buttonText: 'Upgrade to Agency',
  },
];

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  initialPlanId = 'pro',
  onOpenAuth,
}) => {
  const { user, profile, recordPaymentAndUpgrade } = useAuth();

  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [selectedPlanId, setSelectedPlanId] = useState<SubscriptionTierType>(initialPlanId);
  const [step, setStep] = useState<'select' | 'checkout' | 'success'>('select');

  // Checkout form fields
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('888');
  const [cardName, setCardName] = useState(user?.displayName || 'Alex Morgan');
  const [postalCode, setPostalCode] = useState('78701');
  const [isProcessing, setIsProcessing] = useState(false);
  const [completedPayment, setCompletedPayment] = useState<SubscriptionPayment | null>(null);

  if (!isOpen) return null;

  const selectedPlan = PRICING_PLANS.find((p) => p.id === selectedPlanId) || PRICING_PLANS[2];
  const price = billingCycle === 'yearly' ? selectedPlan.priceYearly : selectedPlan.priceMonthly;
  const totalBilled = billingCycle === 'yearly' ? price * 12 : price;

  const handleSelectPlan = (plan: PricingPlan) => {
    if (plan.id === 'free') {
      onClose();
      return;
    }
    setSelectedPlanId(plan.id);
    if (!user) {
      onClose();
      onOpenAuth();
      return;
    }
    setStep('checkout');
  };

  const handleCompletePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onClose();
      onOpenAuth();
      return;
    }

    setIsProcessing(true);

    try {
      // Simulate real processor latency (1.5s)
      await new Promise((r) => setTimeout(r, 1500));

      const payment = await recordPaymentAndUpgrade({
        planId: selectedPlan.id,
        planName: selectedPlan.name,
        amount: totalBilled,
        currency: 'USD',
        paymentMethod: 'card_visa',
        billingInterval: billingCycle,
        status: 'succeeded',
        transactionId: 'txn_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      });

      setCompletedPayment(payment);
      setStep('success');

      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#10b981', '#34d399', '#059669', '#38bdf8', '#fbbf24'],
        });
      } catch (e) {
        // ignore
      }
    } catch (err: any) {
      console.error('Payment failure:', err);
      alert('Payment processing error: ' + (err.message || 'Please try again.'));
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFillDemoCard = () => {
    setCardNumber('4242 4242 4242 4242');
    setCardExpiry('08/29');
    setCardCvc('314');
    setPostalCode('90210');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden text-slate-100 flex flex-col my-auto max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 sticky top-0 z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-white">
                {step === 'select'
                  ? 'Upgrade Your BizForge AI Workspace'
                  : step === 'checkout'
                  ? 'Secure Checkout & Activation'
                  : 'Subscription Activated!'}
              </h3>
              <p className="text-xs text-slate-400">
                {step === 'select'
                  ? 'Transparent pricing. Cancel anytime in one click.'
                  : '256-Bit Encrypted Payment Processing'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* STEP 1: Plan Selection */}
          {step === 'select' && (
            <div className="space-y-6">
              {/* Billing Cycle Toggle */}
              <div className="flex items-center justify-center gap-3 text-xs">
                <span className={billingCycle === 'monthly' ? 'text-white font-bold' : 'text-slate-400'}>
                  Monthly Billing
                </span>
                <button
                  type="button"
                  onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
                  className="w-12 h-6 bg-slate-800 rounded-full p-0.5 border border-slate-700 relative transition-colors"
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-emerald-400 shadow-md transition-transform ${
                      billingCycle === 'yearly' ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
                <div className="flex items-center gap-1.5">
                  <span className={billingCycle === 'yearly' ? 'text-white font-bold' : 'text-slate-400'}>
                    Yearly Billing
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Save 20%
                  </span>
                </div>
              </div>

              {/* Plans Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {PRICING_PLANS.map((plan) => {
                  const isCurrent = profile?.subscriptionTier === plan.id;
                  const displayPrice = billingCycle === 'yearly' ? plan.priceYearly : plan.priceMonthly;

                  return (
                    <div
                      key={plan.id}
                      className={`relative bg-slate-950/70 border rounded-2xl p-5 flex flex-col justify-between transition-all ${
                        plan.popular
                          ? 'border-emerald-500 shadow-lg shadow-emerald-950/30 ring-1 ring-emerald-500/50'
                          : 'border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {plan.popular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-extrabold text-[10px] uppercase tracking-wider shadow">
                          Most Popular
                        </div>
                      )}

                      <div className="space-y-3">
                        <div>
                          <h4 className="font-extrabold text-base text-white">{plan.name}</h4>
                          <p className="text-[11px] text-slate-400 min-h-[32px] mt-1">{plan.tagline}</p>
                        </div>

                        <div className="pb-3 border-b border-slate-800">
                          <div className="flex items-baseline gap-1">
                            <span className="text-2xl sm:text-3xl font-extrabold text-white">
                              ${displayPrice}
                            </span>
                            <span className="text-xs text-slate-400">/month</span>
                          </div>
                          {billingCycle === 'yearly' && plan.priceYearly > 0 && (
                            <span className="text-[10px] text-emerald-400 block mt-0.5">
                              Billed annually (${plan.priceYearly * 12}/yr)
                            </span>
                          )}
                        </div>

                        <ul className="text-xs space-y-2 text-slate-300">
                          {plan.features.map((feat, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                              <span className="text-[11px] leading-tight">{feat}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="pt-5">
                        <button
                          type="button"
                          onClick={() => handleSelectPlan(plan)}
                          disabled={isCurrent}
                          className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                            isCurrent
                              ? 'bg-slate-800 text-slate-400 border border-slate-700 cursor-not-allowed'
                              : plan.popular
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950/40'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                          }`}
                        >
                          <span>{isCurrent ? 'Current Plan' : plan.buttonText}</span>
                          {!isCurrent && <ArrowRight className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Guarantees */}
              <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800 flex flex-wrap items-center justify-around gap-4 text-xs text-slate-400">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Instant Activation & Cloud Sync
                </span>
                <span className="flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-teal-400" />
                  256-Bit Bank-Grade Encryption
                </span>
                <span className="flex items-center gap-1.5">
                  <BadgeCheck className="w-4 h-4 text-amber-400" />
                  30-Day Money-Back Guarantee
                </span>
              </div>
            </div>
          )}

          {/* STEP 2: Checkout Form */}
          {step === 'checkout' && (
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              {/* Order summary */}
              <div className="md:col-span-2 bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4 flex flex-col justify-between">
                <div>
                  <button
                    type="button"
                    onClick={() => setStep('select')}
                    className="text-xs text-slate-400 hover:text-emerald-400 mb-3 flex items-center gap-1 transition-colors"
                  >
                    ← Change Plan
                  </button>

                  <h4 className="font-bold text-sm text-slate-100 uppercase tracking-wider">
                    Order Summary
                  </h4>

                  <div className="mt-3 p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
                    <div className="flex justify-between items-center font-bold text-slate-100">
                      <span>{selectedPlan.name}</span>
                      <span className="text-emerald-400">${totalBilled}</span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Billing Cycle: <strong className="text-slate-200 capitalize">{billingCycle}</strong>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Auto-renews every {billingCycle === 'yearly' ? 'year' : 'month'}.
                    </div>
                  </div>

                  <ul className="mt-4 space-y-2 text-[11px] text-slate-300">
                    {selectedPlan.features.slice(0, 4).map((f, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-3 border-t border-slate-800 text-xs">
                  <div className="flex justify-between font-bold text-slate-100 text-sm">
                    <span>Total Due Today:</span>
                    <span className="text-emerald-400 font-mono">${totalBilled}.00 USD</span>
                  </div>
                </div>
              </div>

              {/* Payment Details Form */}
              <div className="md:col-span-3 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-emerald-400" />
                    Payment Method
                  </h4>
                  <button
                    type="button"
                    onClick={handleFillDemoCard}
                    className="text-[11px] text-emerald-400 hover:underline font-semibold flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3" />
                    Fill Demo Card (Testing)
                  </button>
                </div>

                <form onSubmit={handleCompletePayment} className="space-y-3.5 text-xs">
                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Name on Card</label>
                    <input
                      type="text"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      placeholder="Alex Morgan"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Card Number</label>
                    <div className="relative">
                      <CreditCard className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        placeholder="4242 4242 4242 4242"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-3.5 py-2.5 text-slate-100 font-mono placeholder:text-slate-600 focus:outline-none focus:border-emerald-500"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-slate-300 font-semibold block mb-1">Expiry (MM/YY)</label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="MM/YY"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 font-mono placeholder:text-slate-600 focus:outline-none focus:border-emerald-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-slate-300 font-semibold block mb-1">CVC / CVV</label>
                      <input
                        type="text"
                        value={cardCvc}
                        onChange={(e) => setCardCvc(e.target.value)}
                        placeholder="123"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 font-mono placeholder:text-slate-600 focus:outline-none focus:border-emerald-500"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Postal / ZIP Code</label>
                    <input
                      type="text"
                      value={postalCode}
                      onChange={(e) => setPostalCode(e.target.value)}
                      placeholder="78701"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full mt-2 py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm rounded-xl shadow-xl shadow-emerald-950/40 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isProcessing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                        <span>Authorizing & Syncing to Cloud...</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4" />
                        <span>Pay ${totalBilled}.00 & Activate {selectedPlan.name}</span>
                      </>
                    )}
                  </button>

                  <p className="text-[11px] text-slate-500 text-center pt-1">
                    Receipt and invoice will be recorded directly into your account history.
                  </p>
                </form>
              </div>
            </div>
          )}

          {/* STEP 3: Payment Success */}
          {step === 'success' && completedPayment && (
            <div className="text-center py-6 space-y-4 max-w-lg mx-auto">
              <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 animate-bounce">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <h4 className="text-2xl font-extrabold text-white">Payment Successful!</h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Congratulations! Your account has been upgraded to{' '}
                <strong className="text-emerald-400">{completedPayment.planName}</strong>. All premium
                business planning capabilities, AI marketing tools, and launch roadmaps are now unlocked.
              </p>

              {/* Receipt card */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs text-left space-y-2">
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Transaction ID:</span>
                  <span className="font-mono text-slate-200">{completedPayment.transactionId}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Plan Activated:</span>
                  <span className="font-bold text-emerald-400">{completedPayment.planName}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Amount Paid:</span>
                  <span className="font-mono font-bold text-white">
                    ${completedPayment.amount} {completedPayment.currency}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Status:</span>
                  <span className="text-emerald-400 font-bold uppercase tracking-wider">
                    {completedPayment.status}
                  </span>
                </div>
              </div>

              <div className="pt-2 flex justify-center gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs transition-colors shadow-lg shadow-emerald-950/40"
                >
                  Start Building Ventures Now
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
