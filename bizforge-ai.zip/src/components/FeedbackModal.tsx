import React, { useState } from 'react';
import { Star, X, CheckCircle2, MessageSquare, Send, Sparkles, AlertCircle } from 'lucide-react';
import { FeedbackItem } from '../types';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  planTitle: string;
  onFeedbackSubmitted?: (item: FeedbackItem) => void;
}

const CATEGORIES = [
  'Overall Quality',
  'Financial & Cost Realism',
  'Market & Customer Clarity',
  '30-Day Launch Roadmap',
  'Actionability & Depth',
  'Other Suggestions',
];

export const FeedbackModal: React.FC<FeedbackModalProps> = ({
  isOpen,
  onClose,
  planTitle,
  onFeedbackSubmitted,
}) => {
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [category, setCategory] = useState<string>('Overall Quality');
  const [message, setMessage] = useState<string>('');
  const [improvements, setImprovements] = useState<string>('');
  const [userEmail, setUserEmail] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!improvements.trim() && !message.trim()) {
      setErrorMessage('Please share your thoughts or suggested improvements.');
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planTitle,
          rating,
          category,
          message,
          improvements,
          userEmail,
          metadata: {
            submittedFrom: 'business-plan-results',
            timestamp: new Date().toISOString(),
          },
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to submit feedback.');
      }

      setSubmitted(true);
      if (onFeedbackSubmitted && data.feedback) {
        onFeedbackSubmitted(data.feedback);
      }

      // Reset after brief delay if user re-opens
      setTimeout(() => {
        setMessage('');
        setImprovements('');
        setUserEmail('');
      }, 1000);
    } catch (err: any) {
      console.error('Feedback error:', err);
      // Fallback: store locally in localStorage even if network had an issue
      const localFeedback: FeedbackItem = {
        id: 'fb_local_' + Date.now(),
        planTitle,
        rating,
        category,
        message,
        improvements,
        userEmail,
        createdAt: new Date().toISOString(),
        status: 'pending_review',
      };
      try {
        const stored = JSON.parse(localStorage.getItem('bizforge_feedbacks') || '[]');
        stored.unshift(localFeedback);
        localStorage.setItem('bizforge_feedbacks', JSON.stringify(stored));
        if (onFeedbackSubmitted) onFeedbackSubmitted(localFeedback);
        setSubmitted(true);
      } catch (localErr) {
        setErrorMessage(err.message || 'Could not save feedback. Please try again.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const getRatingLabel = (stars: number) => {
    switch (stars) {
      case 1:
        return 'Needs Significant Work';
      case 2:
        return 'Fair - Missing Details';
      case 3:
        return 'Good - Useful Foundations';
      case 4:
        return 'Very Good - Actionable & Clear';
      case 5:
        return 'Outstanding - Investment Grade!';
      default:
        return '';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl shadow-emerald-950/20 overflow-hidden text-slate-100 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 sticky top-0 z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-100 flex items-center gap-1.5">
                Feedback & Improvements
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              </h3>
              <p className="text-xs text-slate-400 truncate max-w-xs">
                For: <span className="text-emerald-400 font-medium">{planTitle || 'Business Plan'}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5">
          {submitted ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 animate-bounce">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-xl font-bold text-slate-100">Feedback Stored for Review!</h4>
              <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                Thank you for your valuable insight. Your ratings and suggestions directly refine our business planning models to produce even sharper, more realistic strategies.
              </p>
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setSubmitted(false);
                    onClose();
                  }}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-semibold text-sm transition-colors shadow-lg shadow-emerald-900/30"
                >
                  Return to Business Plan
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {errorMessage && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Star Rating */}
              <div className="bg-slate-800/40 border border-slate-800 p-4 rounded-xl text-center space-y-2">
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  How would you rate the quality of this plan?
                </label>
                <div className="flex items-center justify-center gap-1.5 pt-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      className="p-1 focus:outline-none transition-transform hover:scale-125"
                      aria-label={`${star} Stars`}
                    >
                      <Star
                        className={`w-7 h-7 transition-colors ${
                          star <= (hoverRating || rating)
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-slate-600'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <p className="text-xs font-medium text-emerald-400 min-h-[18px]">
                  {getRatingLabel(hoverRating || rating)}
                </p>
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Feedback Focus Area
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCategory(cat)}
                      className={`px-3 py-2 rounded-lg text-left border transition-all ${
                        category === cat
                          ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300 font-semibold'
                          : 'bg-slate-800/40 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Suggestions / Improvements */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Suggested Improvements & Missing Details <span className="text-emerald-400">*</span>
                </label>
                <textarea
                  rows={3}
                  value={improvements}
                  onChange={(e) => setImprovements(e.target.value)}
                  placeholder="What sections could be more realistic? Any missing costs, better pricing models, or market nuances you would like to see?"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all resize-none"
                  required
                />
              </div>

              {/* What went well */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  What parts were most helpful or accurate? (Optional)
                </label>
                <textarea
                  rows={2}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="e.g. The 30-day roadmap and pricing tiers were spot on..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all resize-none"
                />
              </div>

              {/* User Email (Optional) */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Email for follow-up (Optional)
                </label>
                <input
                  type="email"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  placeholder="founder@example.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {/* Footer actions */}
              <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-slate-400 hover:text-slate-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl font-semibold text-sm transition-all flex items-center gap-2 shadow-lg shadow-emerald-950/40"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Submit Feedback</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
