import React, { useState, useEffect } from 'react';
import { Star, X, Trash2, MessageSquare, RefreshCw, Calendar, Tag, ShieldCheck, Mail } from 'lucide-react';
import { FeedbackItem } from '../types';

interface FeedbackReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  feedbacks: FeedbackItem[];
  onRefresh: () => void;
  onDeleteFeedback: (id: string) => void;
}

export const FeedbackReviewModal: React.FC<FeedbackReviewModalProps> = ({
  isOpen,
  onClose,
  feedbacks,
  onRefresh,
  onDeleteFeedback,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterRating, setFilterRating] = useState<number | 'all'>('all');
  const [isDeleting, setIsDeleting] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      onRefresh();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const filteredFeedbacks = feedbacks.filter((item) => {
    if (filterCategory !== 'all' && item.category !== filterCategory) return false;
    if (filterRating !== 'all' && item.rating !== filterRating) return false;
    return true;
  });

  const averageRating =
    feedbacks.length > 0
      ? (feedbacks.reduce((acc, curr) => acc + (curr.rating || 5), 0) / feedbacks.length).toFixed(1)
      : '5.0';

  const handleDelete = async (id: string) => {
    setIsDeleting(id);
    try {
      await fetch(`/api/feedback/${id}`, { method: 'DELETE' });
      onDeleteFeedback(id);
    } catch (err) {
      console.error('Failed to delete feedback:', err);
      onDeleteFeedback(id);
    } finally {
      setIsDeleting(null);
    }
  };

  const categories = Array.from(new Set(feedbacks.map((f) => f.category).filter(Boolean)));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-slate-100 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/95 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-slate-100 flex items-center gap-2">
                User Feedback Review Log
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {feedbacks.length} Submissions
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Audited feedback & improvement suggestions on AI business plan generations
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onRefresh}
              className="p-2 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-lg transition-colors"
              title="Refresh Feedback"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Analytics bar */}
        <div className="px-6 py-3 bg-slate-950/60 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-400">Average Quality:</span>
              <div className="flex items-center gap-1 font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-md border border-amber-400/20">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span>{averageRating} / 5.0</span>
              </div>
            </div>
            <div className="h-4 w-px bg-slate-800 hidden sm:block" />
            <div className="text-slate-400">
              Total Recorded: <span className="font-semibold text-slate-200">{feedbacks.length}</span>
            </div>
          </div>

          {/* Filters */}
          <div className="flex items-center gap-2 flex-wrap">
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="bg-slate-900 border border-slate-800 text-slate-300 rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            <select
              value={filterRating}
              onChange={(e) => setFilterRating(e.target.value === 'all' ? 'all' : Number(e.target.value))}
              className="bg-slate-900 border border-slate-800 text-slate-300 rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="all">All Ratings</option>
              <option value="5">5 Stars</option>
              <option value="4">4 Stars</option>
              <option value="3">3 Stars</option>
              <option value="2">2 Stars</option>
              <option value="1">1 Star</option>
            </select>
          </div>
        </div>

        {/* Submissions List */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {filteredFeedbacks.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-slate-800 rounded-xl">
              <MessageSquare className="w-10 h-10 text-slate-600 mx-auto mb-2" />
              <p className="text-slate-400 font-medium text-sm">No feedback submissions match your filter.</p>
              <p className="text-xs text-slate-500 mt-1">
                Generate a business plan and click "Rate & Improvements" to submit feedback!
              </p>
            </div>
          ) : (
            filteredFeedbacks.map((item) => (
              <div
                key={item.id}
                className="bg-slate-950/70 border border-slate-800 hover:border-slate-700/80 rounded-xl p-4 transition-all space-y-3"
              >
                {/* Header row */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm text-slate-100">{item.planTitle}</span>
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                        <Tag className="w-3 h-3" />
                        {item.category}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-[11px] text-slate-500">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(item.createdAt).toLocaleDateString()} at{' '}
                        {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      {item.userEmail && (
                        <span className="flex items-center gap-1 text-slate-400">
                          <Mail className="w-3 h-3" />
                          {item.userEmail}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-0.5 px-2 py-1 bg-amber-400/10 border border-amber-400/20 rounded-md">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star
                          key={s}
                          className={`w-3.5 h-3.5 ${
                            s <= item.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-700'
                          }`}
                        />
                      ))}
                    </div>
                    <button
                      onClick={() => handleDelete(item.id)}
                      disabled={isDeleting === item.id}
                      className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                      title="Delete review item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Improvements textarea */}
                {item.improvements && (
                  <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 text-xs">
                    <span className="text-emerald-400 font-semibold block mb-1">
                      Suggested Improvements:
                    </span>
                    <p className="text-slate-300 whitespace-pre-line leading-relaxed">{item.improvements}</p>
                  </div>
                )}

                {/* What went well message */}
                {item.message && (
                  <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800/80 text-xs">
                    <span className="text-slate-400 font-medium block mb-1">Founder Praise / Accurate Details:</span>
                    <p className="text-slate-300 whitespace-pre-line leading-relaxed">{item.message}</p>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between text-xs text-slate-400">
          <span>Feedback is securely stored on the server in JSON format.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
