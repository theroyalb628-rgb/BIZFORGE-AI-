import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Mail,
  MapPin,
  DollarSign,
  Briefcase,
  ShieldCheck,
  CreditCard,
  LogOut,
  Save,
  CheckCircle2,
  Sparkles,
  ExternalLink,
  Receipt,
  Calendar,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserProfile } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenPayment: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  onOpenPayment,
}) => {
  const { user, profile, updateUserProfile, logout, userPayments } = useAuth();

  const [displayName, setDisplayName] = useState(profile?.displayName || user?.displayName || '');
  const [country, setCountry] = useState(profile?.country || 'United States');
  const [city, setCity] = useState(profile?.city || 'Austin');
  const [defaultCurrency, setDefaultCurrency] = useState(profile?.defaultCurrency || 'USD');
  const [businessFocus, setBusinessFocus] = useState(profile?.businessFocus || 'Digital & Local Services');
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.displayName || user?.displayName || '');
      setCountry(profile.country || 'United States');
      setCity(profile.city || 'Austin');
      setDefaultCurrency(profile.defaultCurrency || 'USD');
      setBusinessFocus(profile.businessFocus || 'Digital & Local Services');
    }
  }, [profile, user]);

  if (!isOpen || !user) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSavedSuccess(false);

    try {
      await updateUserProfile({
        displayName,
        country,
        city,
        defaultCurrency,
        businessFocus,
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } catch (err) {
      console.error(err);
      alert('Failed to save profile updates.');
    } finally {
      setIsSaving(false);
    }
  };

  const getTierBadge = () => {
    const tier = profile?.subscriptionTier || 'free';
    switch (tier) {
      case 'starter':
        return { label: 'Starter Builder', color: 'bg-teal-500/20 text-teal-300 border-teal-500/30' };
      case 'pro':
        return { label: 'Pro Venture', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' };
      case 'unlimited':
        return { label: 'Agency Unlimited', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' };
      default:
        return { label: 'Free Founder', color: 'bg-slate-800 text-slate-300 border-slate-700' };
    }
  };

  const badge = getTierBadge();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden text-slate-100 flex flex-col my-auto max-h-[90vh]">
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/95 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-sm">
              {displayName ? displayName.charAt(0).toUpperCase() : user.email?.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-white">{displayName || 'Founder'}</h3>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border uppercase tracking-wider ${badge.color}`}>
                  {badge.label}
                </span>
              </div>
              <p className="text-xs text-slate-400">{user.email}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {savedSuccess && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Profile settings saved and synced to cloud!</span>
            </div>
          )}

          {/* Subscription Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 to-slate-950 border border-emerald-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Current Plan:</span>
                <strong className="text-emerald-400 font-extrabold text-sm">{badge.label}</strong>
              </div>
              <p className="text-[11px] text-slate-300 mt-0.5">
                Status: <span className="text-emerald-400 font-semibold capitalize">{profile?.subscriptionStatus || 'Active'}</span> • AI Credits Remaining: <strong className="text-white">{profile?.creditsRemaining ?? 3}</strong>
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenPayment();
              }}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-md shadow-emerald-950/30 shrink-0"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{profile?.subscriptionTier === 'free' ? 'Upgrade Plan' : 'Change / Renew Plan'}</span>
            </button>
          </div>

          {/* Profile Settings Form */}
          <form onSubmit={handleSave} className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h4 className="font-bold text-sm text-slate-200 flex items-center gap-2">
                <User className="w-4 h-4 text-emerald-400" />
                Founder & Business Preferences
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Display Name</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Your Name"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Account Email</label>
                <input
                  type="email"
                  value={user.email || ''}
                  disabled
                  className="w-full bg-slate-950/50 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-500 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">City</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g. Austin"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Country</label>
                <input
                  type="text"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  placeholder="e.g. United States"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Default Currency</label>
                <select
                  value={defaultCurrency}
                  onChange={(e) => setDefaultCurrency(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                >
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="CAD">CAD (CA$)</option>
                  <option value="AUD">AUD (A$)</option>
                  <option value="INR">INR (₹)</option>
                  <option value="NGN">NGN (₦)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Primary Business Focus</label>
                <input
                  type="text"
                  value={businessFocus}
                  onChange={(e) => setBusinessFocus(e.target.value)}
                  placeholder="e.g. B2B SaaS, Local Services"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="submit"
                disabled={isSaving}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-md shadow-emerald-950/30"
              >
                {isSaving ? (
                  <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Settings</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Payment History & Receipts */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h4 className="font-bold text-sm text-slate-200 flex items-center gap-2">
                <Receipt className="w-4 h-4 text-teal-400" />
                Billing & Receipt History
              </h4>
              <span className="text-[11px] text-slate-400">{userPayments.length} transactions</span>
            </div>

            {userPayments.length === 0 ? (
              <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800 text-center text-xs text-slate-500">
                No past transactions recorded yet. When you upgrade, receipts appear here.
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-800 rounded-xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                    <tr>
                      <th className="px-3.5 py-2.5">Date</th>
                      <th className="px-3.5 py-2.5">Plan</th>
                      <th className="px-3.5 py-2.5">Amount</th>
                      <th className="px-3.5 py-2.5">Status</th>
                      <th className="px-3.5 py-2.5">Transaction ID</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {userPayments.map((pay) => (
                      <tr key={pay.id} className="hover:bg-slate-800/30">
                        <td className="px-3.5 py-2 text-slate-400">
                          {new Date(pay.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-3.5 py-2 font-semibold text-white">{pay.planName}</td>
                        <td className="px-3.5 py-2 font-mono text-emerald-400">
                          ${pay.amount} {pay.currency}
                        </td>
                        <td className="px-3.5 py-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 uppercase">
                            {pay.status}
                          </span>
                        </td>
                        <td className="px-3.5 py-2 font-mono text-[10px] text-slate-500 truncate max-w-[120px]">
                          {pay.transactionId}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/90 flex items-center justify-between text-xs">
          <button
            type="button"
            onClick={async () => {
              await logout();
              onClose();
            }}
            className="text-rose-400 hover:text-rose-300 font-semibold flex items-center gap-1.5 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
