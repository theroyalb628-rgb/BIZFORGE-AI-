import React, { useState } from 'react';
import {
  Copy,
  Check,
  Printer,
  Download,
  FileDown,
  Edit3,
  Save,
  MessageSquare,
  Sparkles,
  TrendingUp,
  DollarSign,
  Users,
  Target,
  AlertTriangle,
  Calendar,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Layers,
  ArrowRight,
  Share2,
} from 'lucide-react';
import { BusinessPlan } from '../types';

interface BusinessPlanViewProps {
  plan: BusinessPlan;
  onUpdatePlan: (updatedPlan: BusinessPlan) => void;
  onOpenFeedback: () => void;
  onNavigateToCalculator: () => void;
  onNavigateToMarketing: () => void;
  onNavigateToRoadmap: () => void;
}

export const BusinessPlanView: React.FC<BusinessPlanViewProps> = ({
  plan,
  onUpdatePlan,
  onOpenFeedback,
  onNavigateToCalculator,
  onNavigateToMarketing,
  onNavigateToRoadmap,
}) => {
  const [activeSection, setActiveSection] = useState<string>('all');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editedPlan, setEditedPlan] = useState<BusinessPlan>(plan);

  // Sync state if plan changes
  React.useEffect(() => {
    setEditedPlan(plan);
    setIsEditing(false);
  }, [plan]);

  const handleCopyText = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2500);
  };

  const handleDownloadPDF = () => {
    const previousTitle = document.title;
    const previousSection = activeSection;

    // Set document title so the browser defaults the PDF filename cleanly
    const sanitizedName = plan.businessName.replace(/[^a-zA-Z0-9 ]/g, '').trim() || 'Business_Plan';
    document.title = `${sanitizedName} - Business Plan`;

    // Ensure all 9 sections are active in the DOM for complete document rendering
    setActiveSection('all');

    // Slight delay to ensure React commits all sections to DOM before print dialog launches
    setTimeout(() => {
      window.print();
      // Restore previous state
      document.title = previousTitle;
      setActiveSection(previousSection);
    }, 120);
  };

  const handleDownloadMarkdown = () => {
    const md = generateMarkdownPlan(plan);
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${plan.businessName.toLowerCase().replace(/[^a-z0-9]/g, '_')}_business_plan.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleSaveEdits = () => {
    onUpdatePlan({
      ...editedPlan,
      updatedAt: new Date().toISOString(),
    });
    setIsEditing(false);
  };

  const handleToggleLaunchTask = (weekIndex: number, taskIndex: number) => {
    const newPlan = { ...plan };
    const task = newPlan.launchPlan30Day.weeks[weekIndex]?.tasks[taskIndex];
    if (task) {
      task.completed = !task.completed;
      onUpdatePlan(newPlan);
    }
  };

  const generateMarkdownPlan = (p: BusinessPlan) => {
    return `# ${p.businessName} - Business Plan
*Tagline: ${p.tagline}*
*Location: ${p.inputs.countryCity} | Starting Budget: ${p.inputs.currency} ${p.inputs.budget}*
*Generated: ${new Date(p.createdAt).toLocaleDateString()}*

---

## 1. Executive Summary
${p.executiveSummary}

**Mission Statement:**
> ${p.missionStatement}

**Unique Value Proposition (UVP):**
${p.uniqueValueProposition}

---

## 2. Target Market & Personas
${p.targetMarket.overview}

**Primary Audience:** ${p.targetMarket.primaryAudience}
${p.targetMarket.marketOpportunity ? `**Market Opportunity:** ${p.targetMarket.marketOpportunity}` : ''}

### Ideal Customer Persona: ${p.targetMarket.idealCustomerPersona.name}
- **Demographics:** ${p.targetMarket.idealCustomerPersona.demographics}
- **Pain Points:**
${p.targetMarket.idealCustomerPersona.painPoints.map((pt) => `  - ${pt}`).join('\n')}
- **Buying Motivation:** ${p.targetMarket.idealCustomerPersona.buyingMotivation}

---

## 3. Customer Problem & Solution
**Core Problem:**
${p.customerProblemAndSolution.coreProblem}

**Current Alternatives & Shortcomings:**
${p.customerProblemAndSolution.currentAlternatives}

**Our Solution:**
${p.customerProblemAndSolution.ourSolution}

${p.customerProblemAndSolution.unfairAdvantage ? `**Unfair Advantage:**\n${p.customerProblemAndSolution.unfairAdvantage}` : ''}

---

## 4. Products & Services
${p.productsAndServices.overview}

${p.productsAndServices.offerings
  .map(
    (off) => `### ${off.name} (${off.priceEstimate})
${off.description}
${off.features ? off.features.map((f) => `- ${f}`).join('\n') : ''}`
  )
  .join('\n\n')}

---

## 5. Revenue Model
**Model Type:** ${p.revenueModel.modelType}
**Expected Gross Margin:** ${p.revenueModel.expectedGrossMargin}
**Pricing Strategy:**
${p.revenueModel.pricingTiersDescription}

${p.revenueModel.customerLifetimeValueStrategy ? `**LTV Strategy:** ${p.revenueModel.customerLifetimeValueStrategy}\n` : ''}
${p.revenueModel.pathwayToFirst10k ? `**Pathway to First $10,000:** ${p.revenueModel.pathwayToFirst10k}\n` : ''}

---

## 6. Startup Cost Estimates
**Total Estimated Budget:** ${p.startupCosts.currency} ${p.startupCosts.totalEstimatedBudget.toLocaleString()}
${p.startupCosts.monthlyEstimatedRunway ? `**Estimated Monthly Burn:** ${p.startupCosts.monthlyEstimatedRunway}\n` : ''}

| Category | Description | Cost | Essential |
|---|---|---|---|
${p.startupCosts.itemizedBreakdown
  .map(
    (item) =>
      `| ${item.category} | ${item.description} | ${p.startupCosts.currency} ${item.cost.toLocaleString()} | ${item.isEssential ? 'Yes' : 'Optional'} |`
  )
  .join('\n')}

${p.startupCosts.moneySavingTips && p.startupCosts.moneySavingTips.length > 0 ? `\n### Money Saving Tips:\n${p.startupCosts.moneySavingTips.map((t) => `- ${t}`).join('\n')}` : ''}

---

## 7. Marketing & Customer Acquisition Strategy
${p.marketingStrategy.preLaunchStrategy ? `**Pre-Launch Strategy:**\n${p.marketingStrategy.preLaunchStrategy}\n\n` : ''}
### Top Channels
${p.marketingStrategy.topChannels
  .map((c) => `- **${c.channel}** (${c.costLevel || 'Standard'}): ${c.tactic}`)
  .join('\n')}

**Pathway to First 100 Customers:**
${p.marketingStrategy.first100CustomersTactic}

---

## 8. Critical Risks & Mitigations
${p.risksAndMitigations
  .map(
    (r) => `### [${r.severity || 'Medium'}] ${r.risk} (${r.category || 'General'})
**Mitigation Solution:** ${r.solution}`
  )
  .join('\n\n')}

---

## 9. 30-Day Launch Plan
${p.launchPlan30Day.summary}

${p.launchPlan30Day.weeks
  .map(
    (w) => `### Week ${w.weekNumber}: ${w.theme}
${w.goals ? `*Goals: ${w.goals}*\n` : ''}
${w.tasks.map((t) => `- **[${t.dayRange}] ${t.title}**: ${t.description}`).join('\n')}`
  )
  .join('\n\n')}

---
*Created with BizForge AI - Turn your idea into a business.*
`;
  };

  const sectionsNav = [
    { id: 'all', label: 'All Sections' },
    { id: 'summary', label: '1. Executive Summary' },
    { id: 'market', label: '2. Target Market' },
    { id: 'problem', label: '3. Problem & UVP' },
    { id: 'products', label: '4. Products & Services' },
    { id: 'revenue', label: '5. Revenue Model' },
    { id: 'costs', label: '6. Startup Costs' },
    { id: 'marketing', label: '7. Marketing' },
    { id: 'risks', label: '8. Risks & Mitigations' },
    { id: 'launch', label: '9. 30-Day Launch' },
  ];

  return (
    <div className="space-y-6">
      {/* Executive PDF Document Header (Visible only when Printing / Saving as PDF) */}
      <div className="hidden print-only mb-6 border-b-2 border-emerald-600 pb-4">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-600 block mb-1">
              BizForge AI • Official Business Plan
            </span>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">{plan.businessName}</h1>
            <p className="text-sm font-semibold text-emerald-700 mt-0.5">{plan.tagline}</p>
            <div className="text-xs text-slate-600 mt-2 flex flex-wrap gap-3">
              <span><strong>Location:</strong> {plan.inputs.countryCity || 'Global'}</span>
              <span><strong>Starting Budget:</strong> {plan.inputs.currency} {Number(plan.inputs.budget).toLocaleString()}</span>
              <span><strong>Business Model:</strong> {plan.inputs.businessType}</span>
            </div>
          </div>
          <div className="text-right text-xs text-slate-500">
            <div className="font-bold text-slate-900">Confidential Executive Document</div>
            <div>Generated: {new Date(plan.createdAt).toLocaleDateString()}</div>
            <div className="text-[10px] text-slate-400 mt-1">bizforge-ai.web.app</div>
          </div>
        </div>
      </div>

      {/* Top Banner / Plan Summary Card */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl -z-10 pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Verified Business Plan
              </span>
              <span className="text-xs text-slate-400">
                📍 {plan.inputs.countryCity || 'Global'}
              </span>
              <span className="text-xs text-slate-400">
                💰 Budget: {plan.inputs.currency} {Number(plan.inputs.budget).toLocaleString()}
              </span>
              <span className="text-xs text-slate-500">
                Type: {plan.inputs.businessType}
              </span>
            </div>

            {isEditing ? (
              <div className="space-y-2">
                <input
                  type="text"
                  value={editedPlan.businessName}
                  onChange={(e) => setEditedPlan({ ...editedPlan, businessName: e.target.value })}
                  className="text-2xl sm:text-3xl font-extrabold text-white bg-slate-950 border border-slate-700 rounded-lg px-3 py-1 w-full"
                />
                <input
                  type="text"
                  value={editedPlan.tagline}
                  onChange={(e) => setEditedPlan({ ...editedPlan, tagline: e.target.value })}
                  className="text-sm text-emerald-400 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1 w-full"
                />
              </div>
            ) : (
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  {plan.businessName}
                </h1>
                <p className="text-sm font-medium text-emerald-400 mt-1">
                  {plan.tagline}
                </p>
              </div>
            )}
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-2 flex-wrap">
            {isEditing ? (
              <button
                onClick={handleSaveEdits}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-950/40 transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Save Changes</span>
              </button>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium border border-slate-700 transition-colors"
                title="Edit plan details directly"
              >
                <Edit3 className="w-3.5 h-3.5 text-slate-400" />
                <span>Edit Plan</span>
              </button>
            )}

            {/* DOWNLOAD AS PDF (First-Class Feature using print styles) */}
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-950/40 transition-all cursor-pointer hover:scale-105"
              title="Download Business Plan as a professional PDF document"
            >
              <FileDown className="w-4 h-4 text-white" />
              <span>Download as PDF</span>
            </button>

            <button
              onClick={() => handleCopyText(generateMarkdownPlan(plan), 'full_plan')}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium border border-slate-700 transition-colors"
              title="Copy complete plan as Markdown"
            >
              {copiedSection === 'full_plan' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-semibold">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copy Plan</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownloadMarkdown}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium border border-slate-700 transition-colors"
              title="Download Markdown file (.md)"
            >
              <Download className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Download .md</span>
            </button>

            {/* FEEDBACK BUTTON (Directly addresses user prompt requirement!) */}
            <button
              onClick={onOpenFeedback}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-semibold shadow-sm transition-all animate-pulse"
              title="Submit feedback on the quality of generated content"
            >
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
              <span>Rate & Feedback</span>
            </button>
          </div>
        </div>

        {/* Quick Launchpad Connectors */}
        <div className="pt-4 flex flex-wrap items-center gap-3 text-xs">
          <span className="text-slate-400 font-medium">Next Steps for this Business:</span>

          <button
            onClick={onNavigateToCalculator}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700/60 transition-colors"
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>Model in Profit Calculator</span>
            <ChevronRight className="w-3 h-3 text-slate-400" />
          </button>

          <button
            onClick={onNavigateToMarketing}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700/60 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-teal-400" />
            <span>Generate Marketing Kit</span>
            <ChevronRight className="w-3 h-3 text-slate-400" />
          </button>

          <button
            onClick={onNavigateToRoadmap}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700/60 transition-colors"
          >
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span>Interactive 30-Day Checklist</span>
            <ChevronRight className="w-3 h-3 text-slate-400" />
          </button>
        </div>
      </div>

      {/* Navigation Filter Pills (Mobile scrollable) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none text-xs">
        {sectionsNav.map((sec) => (
          <button
            key={sec.id}
            onClick={() => setActiveSection(sec.id)}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors shrink-0 ${
              activeSection === sec.id
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                : 'bg-slate-800/70 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            {sec.label}
          </button>
        ))}
      </div>

      {/* Section Content Cards */}
      <div className="space-y-6">
        {/* 1. Executive Summary & Mission */}
        {(activeSection === 'all' || activeSection === 'summary') && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <Layers className="w-4 h-4" />
                </div>
                <h2 className="text-lg font-bold text-slate-100">1. Executive Summary & Mission</h2>
              </div>
              <button
                onClick={() =>
                  handleCopyText(
                    `Executive Summary:\n${plan.executiveSummary}\n\nMission:\n${plan.missionStatement}\n\nUVP:\n${plan.uniqueValueProposition}`,
                    'sec_1'
                  )
                }
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {copiedSection === 'sec_1' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'sec_1' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            {isEditing ? (
              <div className="space-y-3">
                <label className="text-xs font-semibold text-slate-400">Executive Summary</label>
                <textarea
                  rows={4}
                  value={editedPlan.executiveSummary}
                  onChange={(e) => setEditedPlan({ ...editedPlan, executiveSummary: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-sm text-slate-200"
                />
                <label className="text-xs font-semibold text-slate-400">Mission Statement</label>
                <input
                  type="text"
                  value={editedPlan.missionStatement}
                  onChange={(e) => setEditedPlan({ ...editedPlan, missionStatement: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-sm text-slate-200"
                />
                <label className="text-xs font-semibold text-slate-400">Unique Value Proposition</label>
                <input
                  type="text"
                  value={editedPlan.uniqueValueProposition}
                  onChange={(e) => setEditedPlan({ ...editedPlan, uniqueValueProposition: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-sm text-slate-200"
                />
              </div>
            ) : (
              <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
                <p className="whitespace-pre-line">{plan.executiveSummary}</p>

                <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <div className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
                    Mission Statement
                  </div>
                  <p className="italic text-slate-200">"{plan.missionStatement}"</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1.5">
                  <div className="text-xs font-semibold uppercase tracking-wider text-teal-400">
                    Unique Value Proposition (UVP)
                  </div>
                  <p className="text-slate-100 font-medium">{plan.uniqueValueProposition}</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 2. Target Market & Personas */}
        {(activeSection === 'all' || activeSection === 'market') && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400">
                  <Target className="w-4 h-4" />
                </div>
                <h2 className="text-lg font-bold text-slate-100">2. Target Market & Ideal Customer</h2>
              </div>
              <button
                onClick={() =>
                  handleCopyText(
                    `Target Market:\n${plan.targetMarket.overview}\n\nPrimary Audience: ${plan.targetMarket.primaryAudience}\n\nPersona: ${plan.targetMarket.idealCustomerPersona.name}\n- Demographics: ${plan.targetMarket.idealCustomerPersona.demographics}\n- Pain points: ${plan.targetMarket.idealCustomerPersona.painPoints.join(', ')}`,
                    'sec_2'
                  )
                }
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {copiedSection === 'sec_2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'sec_2' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="space-y-4 text-sm text-slate-300">
              <p className="leading-relaxed">{plan.targetMarket.overview}</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                  <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider block mb-1">
                    Primary Audience Segment
                  </span>
                  <p className="text-slate-200">{plan.targetMarket.primaryAudience}</p>
                  {plan.targetMarket.marketOpportunity && (
                    <div className="mt-3 pt-3 border-t border-slate-800/80">
                      <span className="text-xs font-semibold text-slate-400 block mb-1">Market Timing</span>
                      <p className="text-xs text-slate-300">{plan.targetMarket.marketOpportunity}</p>
                    </div>
                  )}
                </div>

                <div className="p-4 rounded-xl bg-slate-950/80 border border-emerald-500/20 space-y-2">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                      Buyer Persona: {plan.targetMarket.idealCustomerPersona.name}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    <strong className="text-slate-300">Profile:</strong> {plan.targetMarket.idealCustomerPersona.demographics}
                  </p>
                  <div>
                    <span className="text-xs font-semibold text-rose-400 block mb-1">Key Pain Points:</span>
                    <ul className="text-xs space-y-1 list-disc list-inside text-slate-300">
                      {plan.targetMarket.idealCustomerPersona.painPoints.map((pt, i) => (
                        <li key={i}>{pt}</li>
                      ))}
                    </ul>
                  </div>
                  <p className="text-xs text-emerald-300 pt-1 border-t border-slate-800/80">
                    <strong>Buying Trigger:</strong> {plan.targetMarket.idealCustomerPersona.buyingMotivation}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 3. Customer Problem & Solution */}
        {(activeSection === 'all' || activeSection === 'problem') && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <h2 className="text-lg font-bold text-slate-100">3. Customer Problem & Solution</h2>
              </div>
              <button
                onClick={() =>
                  handleCopyText(
                    `Core Problem:\n${plan.customerProblemAndSolution.coreProblem}\n\nCurrent Alternatives:\n${plan.customerProblemAndSolution.currentAlternatives}\n\nOur Solution:\n${plan.customerProblemAndSolution.ourSolution}`,
                    'sec_3'
                  )
                }
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {copiedSection === 'sec_3' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'sec_3' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-500/20 space-y-2">
                <span className="text-xs font-bold text-rose-400 uppercase tracking-wider block">
                  The Critical Problem
                </span>
                <p className="text-slate-200 leading-relaxed">
                  {plan.customerProblemAndSolution.coreProblem}
                </p>
                <div className="pt-2 text-xs text-slate-400 border-t border-rose-900/30">
                  <strong className="text-rose-300">Why current options fail:</strong> {plan.customerProblemAndSolution.currentAlternatives}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                  Our Differentiated Solution
                </span>
                <p className="text-slate-100 leading-relaxed font-medium">
                  {plan.customerProblemAndSolution.ourSolution}
                </p>
                {plan.customerProblemAndSolution.unfairAdvantage && (
                  <div className="pt-2 text-xs text-emerald-300 border-t border-emerald-900/30">
                    <strong className="text-emerald-400">Defensible Advantage:</strong> {plan.customerProblemAndSolution.unfairAdvantage}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 4. Products & Services */}
        {(activeSection === 'all' || activeSection === 'products') && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <DollarSign className="w-4 h-4" />
                </div>
                <h2 className="text-lg font-bold text-slate-100">4. Products & Service Packages</h2>
              </div>
              <button
                onClick={() =>
                  handleCopyText(
                    plan.productsAndServices.offerings
                      .map((o) => `${o.name} (${o.priceEstimate})\n${o.description}`)
                      .join('\n\n'),
                    'sec_4'
                  )
                }
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {copiedSection === 'sec_4' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'sec_4' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <p className="text-sm text-slate-300">{plan.productsAndServices.overview}</p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
              {plan.productsAndServices.offerings.map((off, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-emerald-500/30 transition-all"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h4 className="font-bold text-slate-100 text-sm">{off.name}</h4>
                      <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
                        {off.priceEstimate}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mb-3 leading-relaxed">{off.description}</p>
                  </div>
                  {off.features && off.features.length > 0 && (
                    <ul className="text-[11px] space-y-1 text-slate-300 pt-2 border-t border-slate-800/80">
                      {off.features.map((feat, fIdx) => (
                        <li key={fIdx} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 5. Revenue Model */}
        {(activeSection === 'all' || activeSection === 'revenue') && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <h2 className="text-lg font-bold text-slate-100">5. Revenue Model & Monetization</h2>
              </div>
              <button
                onClick={() =>
                  handleCopyText(
                    `Model: ${plan.revenueModel.modelType}\nGross Margin: ${plan.revenueModel.expectedGrossMargin}\nPricing: ${plan.revenueModel.pricingTiersDescription}\nPathway to First $10k: ${plan.revenueModel.pathwayToFirst10k || 'N/A'}`,
                    'sec_5'
                  )
                }
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {copiedSection === 'sec_5' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'sec_5' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5">
                <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold block">
                  Core Revenue Structure
                </span>
                <p className="text-base font-bold text-slate-100">{plan.revenueModel.modelType}</p>
                <div className="text-xs text-emerald-400 font-medium">
                  Expected Gross Margin: {plan.revenueModel.expectedGrossMargin}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5">
                <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold block">
                  Pathway to First $10k Revenue
                </span>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {plan.revenueModel.pathwayToFirst10k || 'Achieve initial 10-15 paying customers at target average order value.'}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800 text-xs text-slate-300 leading-relaxed">
              <strong className="text-slate-100 block mb-1">Pricing Strategy & Retention Dynamics:</strong>
              {plan.revenueModel.pricingTiersDescription}
              {plan.revenueModel.customerLifetimeValueStrategy && (
                <p className="mt-2 text-slate-400">
                  <strong className="text-slate-300">LTV Strategy:</strong> {plan.revenueModel.customerLifetimeValueStrategy}
                </p>
              )}
            </div>
          </div>
        )}

        {/* 6. Startup Cost Estimates */}
        {(activeSection === 'all' || activeSection === 'costs') && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <DollarSign className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-100">6. Startup Cost Estimates</h2>
                  <p className="text-xs text-slate-400">Itemized capital required to reach launch and initial customers</p>
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs text-slate-400">Estimated Total</div>
                <div className="text-lg sm:text-xl font-extrabold text-emerald-400">
                  {plan.startupCosts.currency} {plan.startupCosts.totalEstimatedBudget.toLocaleString()}
                </div>
              </div>
            </div>

            {/* Comparison vs Starting Budget */}
            <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">
                  Budget Utilization: {plan.startupCosts.currency} {plan.startupCosts.totalEstimatedBudget.toLocaleString()} of {plan.startupCosts.currency} {Number(plan.inputs.budget).toLocaleString()}
                </span>
                <span className="font-semibold text-emerald-400">
                  {Math.round((plan.startupCosts.totalEstimatedBudget / (Number(plan.inputs.budget) || 1)) * 100)}% Used
                </span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-500 h-full rounded-full transition-all"
                  style={{
                    width: `${Math.min(
                      100,
                      Math.round((plan.startupCosts.totalEstimatedBudget / (Number(plan.inputs.budget) || 1)) * 100)
                    )}%`,
                  }}
                />
              </div>
              {plan.startupCosts.monthlyEstimatedRunway && (
                <div className="text-[11px] text-slate-400">
                  Monthly operational burn: <span className="text-slate-200">{plan.startupCosts.monthlyEstimatedRunway}</span>
                </div>
              )}
            </div>

            {/* Itemized Table */}
            <div className="overflow-x-auto border border-slate-800 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Description</th>
                    <th className="px-4 py-3 text-right">Cost</th>
                    <th className="px-4 py-3 text-center">Priority</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {plan.startupCosts.itemizedBreakdown.map((item, i) => (
                    <tr key={i} className="hover:bg-slate-800/30">
                      <td className="px-4 py-2.5 font-semibold text-slate-200">{item.category}</td>
                      <td className="px-4 py-2.5 text-slate-300">{item.description}</td>
                      <td className="px-4 py-2.5 text-right font-mono font-bold text-emerald-400">
                        {plan.startupCosts.currency} {item.cost.toLocaleString()}
                      </td>
                      <td className="px-4 py-2.5 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                            item.isEssential
                              ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {item.isEssential ? 'Essential' : 'Optional'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Money Saving Tips */}
            {plan.startupCosts.moneySavingTips && plan.startupCosts.moneySavingTips.length > 0 && (
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> Founder Bootstrapping Tips:
                </span>
                <ul className="text-xs space-y-1.5 list-disc list-inside text-slate-300">
                  {plan.startupCosts.moneySavingTips.map((tip, idx) => (
                    <li key={idx}>{tip}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        {/* 7. Marketing Strategy */}
        {(activeSection === 'all' || activeSection === 'marketing') && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400">
                  <Target className="w-4 h-4" />
                </div>
                <h2 className="text-lg font-bold text-slate-100">7. Marketing & Customer Acquisition</h2>
              </div>
              <button
                onClick={() =>
                  handleCopyText(
                    `Marketing Strategy:\n${plan.marketingStrategy.topChannels.map((c) => `- ${c.channel}: ${c.tactic}`).join('\n')}\n\nFirst 100 Customers: ${plan.marketingStrategy.first100CustomersTactic}`,
                    'sec_7'
                  )
                }
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {copiedSection === 'sec_7' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'sec_7' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            {plan.marketingStrategy.preLaunchStrategy && (
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                  Pre-Launch Momentum Strategy
                </span>
                <p className="text-xs text-slate-200 leading-relaxed">{plan.marketingStrategy.preLaunchStrategy}</p>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {plan.marketingStrategy.topChannels.map((chan, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className="font-bold text-xs text-slate-100">{chan.channel}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                        {chan.costLevel || 'Low'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{chan.tactic}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-xl bg-slate-950/80 border border-emerald-500/20 text-xs text-slate-200 space-y-1">
              <strong className="text-emerald-400 font-bold block">Road to First 100 Paying Customers:</strong>
              <p className="leading-relaxed">{plan.marketingStrategy.first100CustomersTactic}</p>
            </div>
          </div>
        )}

        {/* 8. Risks and Solutions */}
        {(activeSection === 'all' || activeSection === 'risks') && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <h2 className="text-lg font-bold text-slate-100">8. Critical Risks & Strategic Solutions</h2>
              </div>
              <button
                onClick={() =>
                  handleCopyText(
                    plan.risksAndMitigations.map((r) => `[${r.severity}] ${r.risk}:\nSolution: ${r.solution}`).join('\n\n'),
                    'sec_8'
                  )
                }
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {copiedSection === 'sec_8' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'sec_8' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {plan.risksAndMitigations.map((riskItem, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <span className="font-bold text-xs text-slate-100">{riskItem.risk}</span>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                          riskItem.severity === 'High'
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : riskItem.severity === 'Medium'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {riskItem.severity || 'Medium'}
                      </span>
                    </div>
                    {riskItem.category && (
                      <span className="text-[10px] text-slate-500 block mb-2">{riskItem.category} Risk</span>
                    )}
                  </div>
                  <div className="pt-2 border-t border-slate-800/80 text-xs text-slate-300 leading-relaxed">
                    <strong className="text-emerald-400">Mitigation: </strong>
                    {riskItem.solution}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 9. 30-Day Launch Plan */}
        {(activeSection === 'all' || activeSection === 'launch') && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <Calendar className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-100">9. 30-Day Business Launch Roadmap</h2>
                  <p className="text-xs text-slate-400">{plan.launchPlan30Day.summary}</p>
                </div>
              </div>
              <button
                onClick={() =>
                  handleCopyText(
                    plan.launchPlan30Day.weeks
                      .map((w) => `Week ${w.weekNumber}: ${w.theme}\n${w.tasks.map((t) => `- [${t.dayRange}] ${t.title}: ${t.description}`).join('\n')}`)
                      .join('\n\n'),
                    'sec_9'
                  )
                }
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {copiedSection === 'sec_9' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'sec_9' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="space-y-4">
              {plan.launchPlan30Day.weeks.map((week, wIdx) => (
                <div
                  key={wIdx}
                  className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-3"
                >
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        Week {week.weekNumber}
                      </span>
                      <h4 className="font-bold text-sm text-slate-100">{week.theme}</h4>
                    </div>
                    {week.goals && <span className="text-[11px] text-slate-400 italic hidden sm:block">{week.goals}</span>}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {week.tasks.map((task, tIdx) => (
                      <div
                        key={tIdx}
                        onClick={() => handleToggleLaunchTask(wIdx, tIdx)}
                        className={`p-3 rounded-lg border transition-all cursor-pointer flex flex-col justify-between ${
                          task.completed
                            ? 'bg-emerald-950/30 border-emerald-500/40 opacity-75'
                            : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                              {task.dayRange}
                            </span>
                            <div className="flex items-center gap-1">
                              {task.completed ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                              ) : (
                                <div className="w-3.5 h-3.5 rounded border border-slate-600 hover:border-emerald-400" />
                              )}
                            </div>
                          </div>
                          <h5 className={`font-semibold text-xs mb-1 ${task.completed ? 'line-through text-slate-400' : 'text-slate-100'}`}>
                            {task.title}
                          </h5>
                          <p className="text-[11px] text-slate-400 leading-relaxed">{task.description}</p>
                        </div>
                        {task.deliverable && (
                          <div className="mt-2 pt-2 border-t border-slate-800 text-[10px] text-slate-500 truncate">
                            🎯 Deliverable: {task.deliverable}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* FEEDBACK SYSTEM BANNER (prominently placed on results page) */}
      <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
              How realistic is this business plan?
              <span className="text-xs font-normal text-emerald-400 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                Feedback System
              </span>
            </h3>
            <p className="text-xs text-slate-300 mt-0.5 max-w-xl">
              Rate the accuracy, startup cost breakdown, or market depth, and suggest specific improvements. Your feedback is recorded and stored for review to make BizForge AI sharper.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto shrink-0 flex-wrap sm:flex-nowrap">
          <button
            onClick={handleDownloadPDF}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs rounded-xl shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
            title="Save complete business plan as professional PDF"
          >
            <FileDown className="w-4 h-4 text-emerald-400" />
            <span>Download as PDF</span>
          </button>

          <button
            onClick={onOpenFeedback}
            className="flex-1 sm:flex-none px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl shadow-lg shadow-emerald-950/40 transition-all flex items-center justify-center gap-2 hover:scale-105 cursor-pointer"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Submit Review & Improvements</span>
          </button>
        </div>
      </div>
    </div>
  );
};
