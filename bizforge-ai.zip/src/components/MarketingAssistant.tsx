import React, { useState, useEffect } from 'react';
import {
  Megaphone,
  Sparkles,
  Copy,
  Check,
  Mail,
  Share2,
  TrendingUp,
  Search,
  MessageCircle,
  AlertCircle,
  Send,
} from 'lucide-react';
import { MarketingKit, BusinessPlan } from '../types';

interface MarketingAssistantProps {
  activePlan: BusinessPlan | null;
}

export const MarketingAssistant: React.FC<MarketingAssistantProps> = ({ activePlan }) => {
  const [businessName, setBusinessName] = useState(activePlan?.businessName || 'EcoSpark Cleaners');
  const [idea, setIdea] = useState(
    activePlan?.inputs.idea || 'Eco-friendly commercial cleaning for tech offices and creative studios'
  );
  const [targetCustomers, setTargetCustomers] = useState(
    activePlan?.inputs.targetCustomers || 'Office Managers, Founders and People Ops in Austin, TX'
  );
  const [mainOffer, setMainOffer] = useState(
    activePlan?.uniqueValueProposition || 'Zero-VOC plant-based hospital grade sanitization with 24/7 client portal'
  );

  const [isLoading, setIsLoading] = useState(false);
  const [marketingKit, setMarketingKit] = useState<MarketingKit | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (activePlan) {
      setBusinessName(activePlan.businessName);
      setIdea(activePlan.inputs.idea);
      setTargetCustomers(activePlan.inputs.targetCustomers);
      setMainOffer(activePlan.uniqueValueProposition);
    }
  }, [activePlan]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    try {
      const res = await fetch('/api/generate-marketing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessName,
          idea,
          targetCustomers,
          mainOffer,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate marketing kit.');
      }

      setMarketingKit(data.marketingKit);
    } catch (err: any) {
      console.error('Marketing generator error:', err);
      setErrorMessage(err.message || 'Could not generate marketing kit. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Hero */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5">
            <Megaphone className="w-3.5 h-3.5 text-indigo-400" />
            AI Marketing Strategist
          </span>
          {activePlan && (
            <span className="text-xs text-slate-400">
              Active Business: <strong className="text-emerald-400">{activePlan.businessName}</strong>
            </span>
          )}
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          AI Marketing Launch Kit
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
          Instantly generate ready-to-deploy launch campaigns, 30-second elevator pitches, high-converting social hooks, 3-part email sequences, and organic SEO pillars.
        </p>

        {errorMessage && (
          <div className="mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleGenerate} className="mt-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Business Name</label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Target Customers</label>
              <input
                type="text"
                value={targetCustomers}
                onChange={(e) => setTargetCustomers(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-slate-300 block mb-1">Core Value Proposition / Offer</label>
              <input
                type="text"
                value={mainOffer}
                onChange={(e) => setMainOffer(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-indigo-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white font-bold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                <span>Generating Full Marketing Campaign Kit...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-indigo-200" />
                <span>Generate Marketing Launch Kit</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Generated Marketing Assets */}
      {marketingKit && (
        <div className="space-y-6 animate-fadeIn">
          {/* Elevator Pitch & Headline */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                    30-Second Elevator Pitch
                  </span>
                  <button
                    onClick={() => handleCopy(marketingKit.elevatorPitch, 'pitch')}
                    className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
                  >
                    {copiedId === 'pitch' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId === 'pitch' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-xs sm:text-sm text-slate-200 italic leading-relaxed">
                  "{marketingKit.elevatorPitch}"
                </p>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                    High-Converting Headline / Hook
                  </span>
                  <button
                    onClick={() => handleCopy(marketingKit.headlineUVP, 'headline')}
                    className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
                  >
                    {copiedId === 'headline' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId === 'headline' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-base sm:text-lg font-bold text-white leading-snug">
                  {marketingKit.headlineUVP}
                </p>
              </div>
            </div>
          </div>

          {/* 3-Part Email Welcome Sequence */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-emerald-400" />
              <h3 className="font-bold text-base text-slate-100">3-Part Automated Customer Onboarding Sequence</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {marketingKit.emailSequence.map((email, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-2"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold text-emerald-400 uppercase">
                        {email.day}
                      </span>
                      <button
                        onClick={() => handleCopy(`Subject: ${email.subjectLine}\n\n${email.bodyContent}`, `email_${idx}`)}
                        className="text-slate-400 hover:text-white"
                      >
                        {copiedId === `email_${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="font-bold text-xs text-slate-100 mb-1">
                      Subject: {email.subjectLine}
                    </div>
                    <p className="text-[11px] text-slate-300 whitespace-pre-line leading-relaxed">
                      {email.bodyContent}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Social Media Content Posts */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Share2 className="w-5 h-5 text-teal-400" />
              <h3 className="font-bold text-base text-slate-100">High-Converting Social Media Hooks</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {marketingKit.socialPosts.map((post, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-2"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-teal-300">
                        {post.platform}
                      </span>
                      <button
                        onClick={() => handleCopy(`${post.hook}\n\n${post.caption}\n\n${post.callToAction || ''}`, `post_${idx}`)}
                        className="text-slate-400 hover:text-white"
                      >
                        {copiedId === `post_${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="font-bold text-xs text-slate-100 mb-1">"{post.hook}"</div>
                    <p className="text-[11px] text-slate-300 leading-relaxed whitespace-pre-line">{post.caption}</p>
                  </div>
                  {post.callToAction && (
                    <div className="pt-2 border-t border-slate-800 text-[10px] text-emerald-400 font-semibold">
                      CTA: {post.callToAction}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Growth Hacks & SEO Pillars */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Growth Hacks */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <h4 className="font-bold text-sm text-slate-100">Low-Cost Founder Growth Hacks</h4>
              </div>
              <div className="space-y-2">
                {marketingKit.growthHacks.map((hack, idx) => (
                  <div key={idx} className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs">
                    <div className="flex items-center justify-between font-bold text-slate-200 mb-1">
                      <span>{hack.title}</span>
                      <span className="text-[10px] text-slate-400">{hack.expectedCost || 'Free'}</span>
                    </div>
                    <p className="text-slate-400 text-[11px]">{hack.steps}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* SEO Keyword Pillars */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-teal-400" />
                <h4 className="font-bold text-sm text-slate-100">SEO Keywords & Content Strategy</h4>
              </div>
              <div className="space-y-2">
                {marketingKit.seoPillars?.map((pillar, idx) => (
                  <div key={idx} className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs">
                    <span className="font-bold text-emerald-400 block mb-1">{pillar.pillar}</span>
                    <div className="flex flex-wrap gap-1 mb-1.5">
                      {pillar.primaryKeywords.map((kw, kIdx) => (
                        <span key={kIdx} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                          {kw}
                        </span>
                      ))}
                    </div>
                    {pillar.articleIdea && (
                      <p className="text-[11px] text-slate-400 italic">Topic: {pillar.articleIdea}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
