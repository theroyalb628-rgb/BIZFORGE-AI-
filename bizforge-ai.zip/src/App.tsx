import React, { useState, useEffect } from 'react';
import {
  FileText,
  Calculator,
  Lightbulb,
  Megaphone,
  Fingerprint,
  CalendarCheck2,
  Sparkles,
  ShieldCheck,
  MessageSquare,
  PlusCircle,
  Flame,
  ArrowRight,
  TrendingUp,
  CreditCard,
  User,
  Zap,
} from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Header, ActiveTab } from './components/Header';
import { BusinessPlanCreator } from './components/BusinessPlanCreator';
import { BusinessPlanView } from './components/BusinessPlanView';
import { ProfitCalculator } from './components/ProfitCalculator';
import { IdeaGenerator } from './components/IdeaGenerator';
import { NameGenerator } from './components/NameGenerator';
import { MarketingAssistant } from './components/MarketingAssistant';
import { LaunchRoadmap } from './components/LaunchRoadmap';
import { FeedbackModal } from './components/FeedbackModal';
import { FeedbackReviewModal } from './components/FeedbackReviewModal';
import { AuthModal } from './components/AuthModal';
import { ProfileModal } from './components/ProfileModal';
import { PaymentModal } from './components/PaymentModal';
import { SAMPLE_PLAN } from './data/samplePlan';
import { BusinessPlan, BusinessPlanInputs, FeedbackItem, SubscriptionTierType } from './types';

function MainApp() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('plan-creator');
  const [activePlan, setActivePlan] = useState<BusinessPlan | null>(null);
  const [savedPlans, setSavedPlans] = useState<BusinessPlan[]>([]);
  const [creatorInitialInputs, setCreatorInitialInputs] = useState<Partial<BusinessPlanInputs>>({});

  // Modals state
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [isFeedbackReviewOpen, setIsFeedbackReviewOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [paymentInitialTier, setPaymentInitialTier] = useState<SubscriptionTierType>('pro');

  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>([]);

  const { user, profile } = useAuth();

  // Load saved plans and feedbacks from localStorage and server
  useEffect(() => {
    try {
      const storedPlans = localStorage.getItem('bizforge_saved_plans');
      if (storedPlans) {
        const parsed: BusinessPlan[] = JSON.parse(storedPlans);
        if (parsed.length > 0) {
          setSavedPlans(parsed);
          setActivePlan(parsed[0]);
        } else {
          setSavedPlans([SAMPLE_PLAN]);
          setActivePlan(SAMPLE_PLAN);
        }
      } else {
        setSavedPlans([SAMPLE_PLAN]);
        setActivePlan(SAMPLE_PLAN);
      }
    } catch (e) {
      setSavedPlans([SAMPLE_PLAN]);
      setActivePlan(SAMPLE_PLAN);
    }

    fetchFeedbacks();
  }, []);

  // Update initial currency in creator if profile has custom currency
  useEffect(() => {
    if (profile?.defaultCurrency) {
      setCreatorInitialInputs((prev) => ({
        ...prev,
        currency: profile.defaultCurrency,
      }));
    }
  }, [profile?.defaultCurrency]);

  const fetchFeedbacks = async () => {
    try {
      const res = await fetch('/api/feedback');
      const data = await res.json();
      if (data.success && Array.isArray(data.feedback)) {
        setFeedbacks(data.feedback);
      }
    } catch (e) {
      try {
        const local = JSON.parse(localStorage.getItem('bizforge_feedbacks') || '[]');
        setFeedbacks(local);
      } catch (err) {
        // ignore
      }
    }
  };

  const handlePlanGenerated = (newPlan: BusinessPlan) => {
    setActivePlan(newPlan);
    const updated = [newPlan, ...savedPlans.filter((p) => p.id !== newPlan.id)];
    setSavedPlans(updated);
    try {
      localStorage.setItem('bizforge_saved_plans', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save to localStorage:', e);
    }
  };

  const handleUpdatePlan = (updatedPlan: BusinessPlan) => {
    setActivePlan(updatedPlan);
    const updated = savedPlans.map((p) => (p.id === updatedPlan.id ? updatedPlan : p));
    setSavedPlans(updated);
    try {
      localStorage.setItem('bizforge_saved_plans', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save to localStorage:', e);
    }
  };

  const handleLoadSample = () => {
    setActivePlan(SAMPLE_PLAN);
    if (!savedPlans.some((p) => p.id === SAMPLE_PLAN.id)) {
      setSavedPlans([SAMPLE_PLAN, ...savedPlans]);
    }
  };

  const handleFeedbackSubmitted = (newFeedback: FeedbackItem) => {
    setFeedbacks([newFeedback, ...feedbacks]);
  };

  const handleDeleteFeedback = (id: string) => {
    setFeedbacks(feedbacks.filter((f) => f.id !== id));
  };

  const handleUseIdeaInPlan = (inputs: Partial<BusinessPlanInputs>) => {
    setCreatorInitialInputs(inputs);
    setActiveTab('plan-creator');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleUseNameInPlan = (name: string, tagline: string) => {
    if (activePlan) {
      const updated = { ...activePlan, businessName: name, tagline };
      handleUpdatePlan(updated);
      setActiveTab('plan-creator');
    } else {
      setCreatorInitialInputs((prev) => ({
        ...prev,
        idea: `${name} (${tagline}): ${prev.idea || ''}`,
      }));
      setActiveTab('plan-creator');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenPaymentWithTier = (tier: SubscriptionTierType = 'pro') => {
    setPaymentInitialTier(tier);
    setIsPaymentOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif] selection:bg-emerald-500 selection:text-white pb-20 lg:pb-0">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        savedPlans={savedPlans}
        activePlan={activePlan}
        onSelectPlan={(plan) => setActivePlan(plan)}
        onOpenFeedbackReview={() => setIsFeedbackReviewOpen(true)}
        feedbackCount={feedbacks.length}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenPayment={() => handleOpenPaymentWithTier('pro')}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-8">
        {/* Account promotion banner if not logged in */}
        {!user && (
          <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-xs sm:text-sm text-white block">
                  Save your plans to the cloud & access Pro tools
                </span>
                <span className="text-[11px] text-slate-400">
                  Create a free account to customize your profile, sync financial calculations, and unlock unlimited planning.
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
              <button
                onClick={() => setIsAuthOpen(true)}
                className="flex-1 sm:flex-none px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-950/40"
              >
                Create Account
              </button>
              <button
                onClick={() => handleOpenPaymentWithTier('pro')}
                className="flex-1 sm:flex-none px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/20 rounded-xl text-xs font-semibold"
              >
                View Plans
              </button>
            </div>
          </div>
        )}

        {/* Tab 1: AI Business Plan Creator (Core Priority) */}
        {activeTab === 'plan-creator' && (
          <div className="space-y-8">
            {activePlan ? (
              <div className="space-y-8">
                {/* Secondary action bar to create a brand new plan */}
                <div className="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-2xl p-4">
                  <div className="flex items-center gap-2.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-xs sm:text-sm text-slate-300 font-medium">
                      Viewing Plan: <strong className="text-white">{activePlan.businessName}</strong>
                    </span>
                  </div>
                  <button
                    onClick={() => setActivePlan(null)}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md transition-all"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>Create New Plan</span>
                  </button>
                </div>

                {/* The Full Business Plan Results View */}
                <BusinessPlanView
                  plan={activePlan}
                  onUpdatePlan={handleUpdatePlan}
                  onOpenFeedback={() => setIsFeedbackOpen(true)}
                  onNavigateToCalculator={() => setActiveTab('calculator')}
                  onNavigateToMarketing={() => setActiveTab('marketing')}
                  onNavigateToRoadmap={() => setActiveTab('launch-roadmap')}
                />
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2">
                  <button
                    onClick={handleLoadSample}
                    className="text-xs text-slate-400 hover:text-emerald-400 flex items-center gap-1.5 transition-colors"
                  >
                    <span>← Back to Sample Business Plan</span>
                  </button>
                </div>

                <BusinessPlanCreator
                  onPlanGenerated={handlePlanGenerated}
                  onLoadSample={handleLoadSample}
                  initialInputs={creatorInitialInputs}
                />
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Profit Calculator */}
        {activeTab === 'calculator' && (
          <ProfitCalculator activePlan={activePlan} />
        )}

        {/* Tab 3: AI Business Idea Generator */}
        {activeTab === 'ideas' && (
          <IdeaGenerator onUseIdeaInPlan={handleUseIdeaInPlan} />
        )}

        {/* Tab 4: AI Marketing Assistant */}
        {activeTab === 'marketing' && (
          <MarketingAssistant activePlan={activePlan} />
        )}

        {/* Tab 5: Business Name Generator */}
        {activeTab === 'names' && (
          <NameGenerator onUseNameInPlan={handleUseNameInPlan} />
        )}

        {/* Tab 6: 30-Day Launch Planner */}
        {activeTab === 'launch-roadmap' && (
          <LaunchRoadmap activePlan={activePlan} />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 px-2 py-1.5 flex items-center justify-around shadow-2xl">
        <button
          onClick={() => setActiveTab('plan-creator')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-semibold transition-colors ${
            activeTab === 'plan-creator' ? 'text-emerald-400' : 'text-slate-400'
          }`}
        >
          <FileText className="w-5 h-5 mb-0.5" />
          <span>Plan</span>
        </button>

        <button
          onClick={() => setActiveTab('calculator')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-semibold transition-colors ${
            activeTab === 'calculator' ? 'text-emerald-400' : 'text-slate-400'
          }`}
        >
          <Calculator className="w-5 h-5 mb-0.5" />
          <span>Profit</span>
        </button>

        <button
          onClick={() => setActiveTab('ideas')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-semibold transition-colors ${
            activeTab === 'ideas' ? 'text-emerald-400' : 'text-slate-400'
          }`}
        >
          <Lightbulb className="w-5 h-5 mb-0.5" />
          <span>Ideas</span>
        </button>

        <button
          onClick={() => setActiveTab('marketing')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-semibold transition-colors ${
            activeTab === 'marketing' ? 'text-emerald-400' : 'text-slate-400'
          }`}
        >
          <Megaphone className="w-5 h-5 mb-0.5" />
          <span>Marketing</span>
        </button>

        <button
          onClick={() => handleOpenPaymentWithTier('pro')}
          className="flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-semibold text-emerald-300"
        >
          <CreditCard className="w-5 h-5 mb-0.5 text-emerald-400" />
          <span>Pricing</span>
        </button>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-10 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Flame className="w-4 h-4" />
              </div>
              <span className="font-bold text-white text-sm">BizForge AI</span>
              <span className="text-slate-500">• Turn your idea into a business</span>
            </div>

            <div className="flex items-center gap-4 flex-wrap text-slate-400">
              <button
                onClick={() => setActiveTab('plan-creator')}
                className="hover:text-emerald-400 transition-colors"
              >
                Plan Creator
              </button>
              <button
                onClick={() => handleOpenPaymentWithTier('pro')}
                className="hover:text-emerald-400 transition-colors text-emerald-400 font-semibold"
              >
                Pricing & Payments
              </button>
              <button
                onClick={() => (user ? setIsProfileOpen(true) : setIsAuthOpen(true))}
                className="hover:text-emerald-400 transition-colors"
              >
                {user ? 'Profile Settings' : 'Create Account'}
              </button>
              <button
                onClick={() => setIsFeedbackReviewOpen(true)}
                className="hover:text-emerald-400 transition-colors flex items-center gap-1"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Feedback Log ({feedbacks.length})</span>
              </button>
            </div>
          </div>

          <div className="border-t border-slate-900 pt-6 flex flex-col sm:flex-row items-center justify-between gap-2 text-slate-500 text-[11px]">
            <p>
              Built for entrepreneurs and founders. Powered by Google Gemini 3.8 Flash & Firebase Cloud Firestore.
            </p>
            <p>
              Secure 256-bit encrypted payments. Zero fake reviews or fake statistics.
            </p>
          </div>
        </div>
      </footer>

      {/* Feedback Submission Modal */}
      <FeedbackModal
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
        planTitle={activePlan ? activePlan.businessName : 'BizForge AI Business Plan'}
        onFeedbackSubmitted={handleFeedbackSubmitted}
      />

      {/* Feedback Review Modal */}
      <FeedbackReviewModal
        isOpen={isFeedbackReviewOpen}
        onClose={() => setIsFeedbackReviewOpen(false)}
        feedbacks={feedbacks}
        onRefresh={fetchFeedbacks}
        onDeleteFeedback={handleDeleteFeedback}
      />

      {/* Authentication Modal (Sign In & Create Account) */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        initialMode="signup"
      />

      {/* User Profile Settings Modal */}
      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        onOpenPayment={() => {
          setIsProfileOpen(false);
          setIsPaymentOpen(true);
        }}
      />

      {/* Payment & Subscription Modal */}
      <PaymentModal
        isOpen={isPaymentOpen}
        onClose={() => setIsPaymentOpen(false)}
        initialPlanId={paymentInitialTier}
        onOpenAuth={() => setIsAuthOpen(true)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
