import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Helper to get GoogleGenAI client
function getAIClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in the environment.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: !!process.env.GEMINI_API_KEY,
    appName: 'BizForge AI',
  });
});

// 1. Generate Business Plan (Primary Priority)
app.post('/api/generate-plan', async (req: Request, res: Response) => {
  try {
    const { idea, countryCity, budget, currency, skills, targetCustomers, businessType } = req.body;

    if (!idea || !idea.trim()) {
      return res.status(400).json({ error: 'Business idea is required.' });
    }

    const ai = getAIClient();

    const prompt = `You are a world-class startup consultant, venture builder, and MBA financial analyst.
Generate a comprehensive, realistic, and highly actionable business plan based on the following founder inputs:

- Business Idea: ${idea}
- Location (Country & City): ${countryCity || 'Global / Online'}
- Starting Budget: ${currency || 'USD'} ${budget || '5,000'}
- Founder Skills & Experience: ${skills || 'General business & management skills'}
- Target Customers: ${targetCustomers || 'General consumers and SMBs'}
- Business Type: ${businessType || 'Digital / Online Business'}

Requirements:
- The startup cost estimates must realistically respect and fit within the starting budget of ${currency || 'USD'} ${budget || '5,000'}.
- Provide practical, battle-tested advice, not generic fluff.
- All 9 required sections must be thoroughly developed:
  1. Business Description (Executive summary, tagline, mission statement, value proposition)
  2. Target Market & Personas (Demographics, market size/trends, target persona profile)
  3. Customer Problem & Solution (Core pain points, why current solutions fail, unfair advantage)
  4. Products & Services (Core offerings, features, pricing strategy)
  5. Revenue Model (Monetization channels, pricing tiers, expected margins, unit economics)
  6. Startup Cost Estimates (Itemized cost list totaling around the starting budget, plus monthly runway burn rate)
  7. Marketing & Customer Acquisition Strategy (Pre-launch, 3 top acquisition channels, CAC optimization, sales funnel)
  8. Critical Risks & Mitigation Plans (Top 3-4 specific operational, financial, or regulatory risks with proactive mitigations)
  9. 30-Day Launch Plan (Structured 4-week timeline broken down by days with specific actionable tasks)`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are BizForge AI, an expert startup advisor and MBA planner. Provide deeply tailored, realistic, non-generic business plans in strict JSON format.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            businessName: { type: Type.STRING, description: 'A catchy proposed business name' },
            tagline: { type: Type.STRING, description: 'Memorable brand tagline' },
            executiveSummary: { type: Type.STRING, description: '2-3 paragraph executive summary' },
            missionStatement: { type: Type.STRING, description: 'Clear mission statement' },
            uniqueValueProposition: { type: Type.STRING, description: 'Core differentiator and UVP' },
            
            targetMarket: {
              type: Type.OBJECT,
              properties: {
                overview: { type: Type.STRING, description: 'Market overview, size, and growth trends' },
                primaryAudience: { type: Type.STRING, description: 'Primary customer segment' },
                idealCustomerPersona: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    demographics: { type: Type.STRING },
                    painPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
                    buyingMotivation: { type: Type.STRING },
                  },
                },
                marketOpportunity: { type: Type.STRING, description: 'Why now is the right time' },
              },
              required: ['overview', 'primaryAudience', 'idealCustomerPersona'],
            },

            customerProblemAndSolution: {
              type: Type.OBJECT,
              properties: {
                coreProblem: { type: Type.STRING, description: 'Detailed root problem faced by customers' },
                currentAlternatives: { type: Type.STRING, description: 'How customers currently solve it and why it falls short' },
                ourSolution: { type: Type.STRING, description: 'Our comprehensive solution' },
                unfairAdvantage: { type: Type.STRING, description: 'Defensible edge / moat' },
              },
              required: ['coreProblem', 'currentAlternatives', 'ourSolution'],
            },

            productsAndServices: {
              type: Type.OBJECT,
              properties: {
                overview: { type: Type.STRING },
                offerings: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      description: { type: Type.STRING },
                      priceEstimate: { type: Type.STRING },
                      features: { type: Type.ARRAY, items: { type: Type.STRING } },
                    },
                    required: ['name', 'description', 'priceEstimate'],
                  },
                },
              },
              required: ['overview', 'offerings'],
            },

            revenueModel: {
              type: Type.OBJECT,
              properties: {
                modelType: { type: Type.STRING, description: 'e.g., Subscription, One-off, Freemium, Marketplace fee, Retainer' },
                pricingTiersDescription: { type: Type.STRING },
                expectedGrossMargin: { type: Type.STRING, description: 'e.g. 70-85%' },
                customerLifetimeValueStrategy: { type: Type.STRING },
                pathwayToFirst10k: { type: Type.STRING, description: 'Milestones to achieve first $10k in revenue' },
              },
              required: ['modelType', 'pricingTiersDescription', 'expectedGrossMargin'],
            },

            startupCosts: {
              type: Type.OBJECT,
              properties: {
                totalEstimatedBudget: { type: Type.NUMBER, description: 'Sum of itemized startup costs' },
                currency: { type: Type.STRING },
                monthlyEstimatedRunway: { type: Type.STRING, description: 'Estimated monthly operational burn' },
                itemizedBreakdown: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      category: { type: Type.STRING, description: 'e.g. Legal & Registration, Tools & Software, Marketing, Inventory' },
                      description: { type: Type.STRING },
                      cost: { type: Type.NUMBER },
                      isEssential: { type: Type.BOOLEAN },
                    },
                    required: ['category', 'description', 'cost', 'isEssential'],
                  },
                },
                moneySavingTips: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: ['totalEstimatedBudget', 'currency', 'itemizedBreakdown'],
            },

            marketingStrategy: {
              type: Type.OBJECT,
              properties: {
                preLaunchStrategy: { type: Type.STRING },
                topChannels: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      channel: { type: Type.STRING },
                      tactic: { type: Type.STRING },
                      costLevel: { type: Type.STRING, description: 'Free, Low, Medium, High' },
                    },
                    required: ['channel', 'tactic'],
                  },
                },
                conversionFunnel: { type: Type.STRING },
                first100CustomersTactic: { type: Type.STRING, description: 'Specific plan to get initial 100 paying customers' },
              },
              required: ['topChannels', 'first100CustomersTactic'],
            },

            risksAndMitigations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  risk: { type: Type.STRING },
                  category: { type: Type.STRING, description: 'Operational, Financial, Market, Legal, Tech' },
                  severity: { type: Type.STRING, description: 'Low, Medium, High' },
                  solution: { type: Type.STRING },
                },
                required: ['risk', 'solution'],
              },
            },

            launchPlan30Day: {
              type: Type.OBJECT,
              properties: {
                summary: { type: Type.STRING },
                weeks: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      weekNumber: { type: Type.INTEGER },
                      theme: { type: Type.STRING },
                      goals: { type: Type.STRING },
                      tasks: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            dayRange: { type: Type.STRING, description: 'e.g. Day 1-2' },
                            title: { type: Type.STRING },
                            description: { type: Type.STRING },
                            deliverable: { type: Type.STRING },
                          },
                          required: ['dayRange', 'title', 'description'],
                        },
                      },
                    },
                    required: ['weekNumber', 'theme', 'tasks'],
                  },
                },
              },
              required: ['summary', 'weeks'],
            },
          },
          required: [
            'businessName',
            'tagline',
            'executiveSummary',
            'targetMarket',
            'customerProblemAndSolution',
            'productsAndServices',
            'revenueModel',
            'startupCosts',
            'marketingStrategy',
            'risksAndMitigations',
            'launchPlan30Day',
          ],
        },
      },
    });

    const rawText = response.text || '{}';
    const plan = JSON.parse(rawText);

    res.json({
      success: true,
      data: plan,
      generatedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error generating business plan:', error);
    res.status(500).json({
      error: error?.message || 'Failed to generate business plan. Please check your Gemini API key or try again.',
    });
  }
});

// 2. AI Business Idea Generator
app.post('/api/generate-ideas', async (req: Request, res: Response) => {
  try {
    const { interests, budget, currency, location, skills, targetIndustry } = req.body;

    const ai = getAIClient();

    const prompt = `Generate 5 realistic, high-potential, modern business ideas based on these founder preferences:
- Interests/Passions: ${interests || 'Technology, productivity, commerce'}
- Available Starting Budget: ${currency || 'USD'} ${budget || '3,000'}
- Location: ${location || 'Global/Remote'}
- Skills & Experience: ${skills || 'Digital skills, problem solving'}
- Preferred Industry/Niche: ${targetIndustry || 'Any profitable sector'}

Ensure the ideas range from quick-to-launch services to scalable products, and are realistic for someone with the specified budget.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              tagline: { type: Type.STRING },
              businessType: { type: Type.STRING },
              summary: { type: Type.STRING },
              targetAudience: { type: Type.STRING },
              estimatedStartupCost: { type: Type.STRING },
              monetization: { type: Type.STRING },
              difficultyLevel: { type: Type.STRING, description: 'Beginner, Intermediate, Advanced' },
              timeToFirstDollar: { type: Type.STRING, description: 'e.g. 7-14 days, 30 days, 60 days' },
              whyItWorks: { type: Type.STRING },
            },
            required: ['name', 'tagline', 'businessType', 'summary', 'estimatedStartupCost', 'monetization'],
          },
        },
      },
    });

    const rawText = response.text || '[]';
    res.json({ success: true, ideas: JSON.parse(rawText) });
  } catch (error: any) {
    console.error('Error generating ideas:', error);
    res.status(500).json({ error: error?.message || 'Failed to generate business ideas.' });
  }
});

// 3. AI Business Name Generator
app.post('/api/generate-names', async (req: Request, res: Response) => {
  try {
    const { idea, industry, style } = req.body;

    const ai = getAIClient();

    const prompt = `Generate 12 creative, brandable, and memorable business names for:
- Business Concept: ${idea || 'Modern digital services business'}
- Industry: ${industry || 'Tech & Services'}
- Name Style Preference: ${style || 'Modern & Punchy (e.g., Stripe, Shopify, Vercel)'}

For each name provide:
- Brand name
- Catchy tagline
- Brand personality/tone
- Domain suggestion (e.g. .com, .io, .co, .ai)
- Why it fits`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              tagline: { type: Type.STRING },
              styleCategory: { type: Type.STRING, description: 'Modern, Classic, Playful, Minimalist, Invented' },
              domainSuggestion: { type: Type.STRING },
              vibe: { type: Type.STRING },
              rationale: { type: Type.STRING },
            },
            required: ['name', 'tagline', 'domainSuggestion', 'rationale'],
          },
        },
      },
    });

    const rawText = response.text || '[]';
    res.json({ success: true, names: JSON.parse(rawText) });
  } catch (error: any) {
    console.error('Error generating names:', error);
    res.status(500).json({ error: error?.message || 'Failed to generate business names.' });
  }
});

// 4. AI Marketing Assistant
app.post('/api/generate-marketing', async (req: Request, res: Response) => {
  try {
    const { businessName, idea, targetCustomers, mainOffer } = req.body;

    const ai = getAIClient();

    const prompt = `Act as a Chief Marketing Officer. Create a ready-to-execute marketing launch kit for:
- Business: ${businessName || 'BizForge Startup'}
- Idea: ${idea}
- Target Customers: ${targetCustomers || 'Entrepreneurs and small business owners'}
- Core Offer/Value: ${mainOffer || 'Quality product with fast execution'}

Provide:
1. Elevator Pitch (30-second spoken pitch)
2. Value Proposition statement (Clear 1-sentence UVP)
3. 3-Part Email Welcome / Launch Sequence (Subject + Body preview)
4. 4 High-Converting Social Media Posts / Hooks (LinkedIn, X/Twitter, Instagram, TikTok)
5. 5 Low-Cost Growth Hacks to get initial traction
6. SEO Keyword Clusters and Content Pillars`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            elevatorPitch: { type: Type.STRING },
            headlineUVP: { type: Type.STRING },
            emailSequence: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  day: { type: Type.STRING },
                  purpose: { type: Type.STRING },
                  subjectLine: { type: Type.STRING },
                  bodyContent: { type: Type.STRING },
                },
                required: ['day', 'subjectLine', 'bodyContent'],
              },
            },
            socialPosts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  platform: { type: Type.STRING },
                  hook: { type: Type.STRING },
                  caption: { type: Type.STRING },
                  callToAction: { type: Type.STRING },
                },
                required: ['platform', 'hook', 'caption'],
              },
            },
            growthHacks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  steps: { type: Type.STRING },
                  expectedCost: { type: Type.STRING },
                },
                required: ['title', 'steps'],
              },
            },
            seoPillars: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  pillar: { type: Type.STRING },
                  primaryKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
                  articleIdea: { type: Type.STRING },
                },
                required: ['pillar', 'primaryKeywords'],
              },
            },
          },
          required: ['elevatorPitch', 'headlineUVP', 'emailSequence', 'socialPosts', 'growthHacks'],
        },
      },
    });

    const rawText = response.text || '{}';
    res.json({ success: true, marketingKit: JSON.parse(rawText) });
  } catch (error: any) {
    console.error('Error generating marketing assets:', error);
    res.status(500).json({ error: error?.message || 'Failed to generate marketing assets.' });
  }
});

// 5. 30-Day Launch Planner Enhancer
app.post('/api/generate-launch-plan', async (req: Request, res: Response) => {
  try {
    const { businessName, idea, businessType, budget, currency } = req.body;

    const ai = getAIClient();

    const prompt = `Create an exhaustive, day-by-day 30-Day Business Launch Roadmap for:
- Business: ${businessName || 'New Venture'}
- Concept: ${idea}
- Type: ${businessType || 'Service & Digital'}
- Starting Budget: ${currency || 'USD'} ${budget || '3,000'}

Split into 4 weeks with concrete, non-fluff tasks for each block of days:
- Week 1: Legal, Foundation, Banking, Tooling & Core Offer Validation
- Week 2: Build MVP / Service Package, Brand Assets & Landing Page
- Week 3: Pre-Launch Marketing, Waitlist, Beta Testing & Outreach
- Week 4: Official Launch, Paid/Organic Traffic Push, First Customer Onboarding & Optimization

Return structured tasks with category badges, day markers, checklist descriptions, and key milestone flags.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            objective: { type: Type.STRING },
            totalTasksCount: { type: Type.INTEGER },
            milestones: { type: Type.ARRAY, items: { type: Type.STRING } },
            days: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  dayNumber: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  category: { type: Type.STRING, description: 'Legal, Product, Marketing, Sales, Operations, Finance' },
                  description: { type: Type.STRING },
                  checklistItems: { type: Type.ARRAY, items: { type: Type.STRING } },
                  estimatedHours: { type: Type.NUMBER },
                  isMilestone: { type: Type.BOOLEAN },
                },
                required: ['dayNumber', 'title', 'category', 'description', 'checklistItems'],
              },
            },
          },
          required: ['title', 'objective', 'days'],
        },
      },
    });

    const rawText = response.text || '{}';
    res.json({ success: true, plan: JSON.parse(rawText) });
  } catch (error: any) {
    console.error('Error generating launch plan:', error);
    res.status(500).json({ error: error?.message || 'Failed to generate launch plan.' });
  }
});

// Feedback Storage Endpoints
const DATA_DIR = path.resolve(__dirname, 'data');
const FEEDBACK_FILE = path.join(DATA_DIR, 'feedback.json');

function ensureFeedbackFile() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(FEEDBACK_FILE)) {
    fs.writeFileSync(FEEDBACK_FILE, JSON.stringify([], null, 2), 'utf-8');
  }
}

function readFeedbackData() {
  ensureFeedbackFile();
  try {
    const raw = fs.readFileSync(FEEDBACK_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

function writeFeedbackData(data: any[]) {
  ensureFeedbackFile();
  fs.writeFileSync(FEEDBACK_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// 6. Submit Feedback on business plan quality and suggested improvements
app.post('/api/feedback', (req: Request, res: Response) => {
  try {
    const { planTitle, rating, category, message, improvements, userEmail, metadata } = req.body;

    if (!rating && !message && !improvements) {
      return res.status(400).json({ error: 'Please provide a rating or message feedback.' });
    }

    const feedbacks = readFeedbackData();
    const newFeedback = {
      id: 'fb_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
      planTitle: planTitle || 'Untitled Plan',
      rating: Number(rating) || 5, // 1 to 5
      category: category || 'Overall Quality', // 'Clarity', 'Financial Realism', 'Launch Roadmap', 'Market Strategy', 'Depth & Actionability', 'Other'
      message: (message || '').trim(),
      improvements: (improvements || '').trim(),
      userEmail: (userEmail || '').trim(),
      metadata: metadata || {},
      createdAt: new Date().toISOString(),
      status: 'pending_review',
    };

    feedbacks.unshift(newFeedback);
    writeFeedbackData(feedbacks);

    res.json({
      success: true,
      message: 'Thank you! Your feedback has been recorded and will help improve future business plan generations.',
      feedback: newFeedback,
    });
  } catch (error: any) {
    console.error('Error saving feedback:', error);
    res.status(500).json({ error: 'Failed to record feedback. Please try again.' });
  }
});

// Get stored feedbacks for review
app.get('/api/feedback', (req: Request, res: Response) => {
  try {
    const feedbacks = readFeedbackData();
    res.json({ success: true, count: feedbacks.length, feedback: feedbacks });
  } catch (error: any) {
    console.error('Error fetching feedback:', error);
    res.status(500).json({ error: 'Failed to fetch stored feedback.' });
  }
});

// Delete feedback item
app.delete('/api/feedback/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    let feedbacks = readFeedbackData();
    feedbacks = feedbacks.filter((f: any) => f.id !== id);
    writeFeedbackData(feedbacks);
    res.json({ success: true, message: 'Feedback entry deleted.' });
  } catch (error: any) {
    console.error('Error deleting feedback:', error);
    res.status(500).json({ error: 'Failed to delete feedback entry.' });
  }
});

// Setup dev server with Vite or production static serving
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BizForge AI Server running at http://0.0.0.0:${PORT} [${isDev ? 'development' : 'production'}]`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
